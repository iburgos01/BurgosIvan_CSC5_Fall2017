/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 24, 2017, 12:48 PM
 * Purpose: Calculate the number of calories
 */

//System Libraries
#include <iostream>  //Input/output Stream Library

using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float nCkie,//The number of cookies eaten
            cal,//The number of calories in a cookie
            totCal;//The total number of calories eaten
    //Initialize Variables
    cal=30;//30 calories per cookie
    
    //Input Data/Variables
    cout<<"Enter the number of cookies eaten"<<endl;
    cin>>nCkie;
    
    //Process or map the inputs to the outputs
    totCal=nCkie*cal;//Calculation for the total number of calories
    
    //Display/Output all pertinent variables
    cout<<"Enter the number of cookies eaten = "<<nCkie<<endl;
    cout<<"The number of calories per cookie = "<<cal<<endl;
    cout<<"The total number of calories eaten = "<<totCal<<" calories"<<endl;
    
    //Exit the program
    return 0;
}