/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 24, 2017, 111:52 AM
 * Purpose: Calculating interest earned
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>

using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float CNVPERC=100;//Conversion for percentage
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float savAmt,//The amount in the savings account
            rate,//The interest rate 
            tCom,//The number of times interest is compounded/year
            totInt,//The total amount of interest added to principal
            amtAft;//Amount of principal after adding the interest
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Enter your principal amount"<<endl;
    cin>>savAmt;
    cout<<"Enter the interest rate"<<endl;
    cin>>rate;
    cout<<"Enter the amount of times rate compounds per year"<<endl;
    cin>>tCom;
    //Process or map the inputs to the outputs
    rate/=CNVPERC;//Calculation for the rate to decimals
    float temp=pow(1+rate/tCom,tCom);
    amtAft=savAmt*temp;//Calculation for the total amount earned
    totInt=amtAft-savAmt;//Calculation for the total interest amount
    
    //Display/Output all pertinent variables
    cout<<"The amount of principal = $"<<savAmt<<endl;
    cout<<"The interest rate = "<<rate*CNVPERC<<"%"<<endl;
    cout<<"The Number of times compounded = "<<tCom<<endl;
    cout<<"The total interest rate amount = $"<<totInt<<endl;
    cout<<"The total amount after adding the interest amount = $"<<amtAft<<endl;
            
    //Exit the program
    return 0;
}