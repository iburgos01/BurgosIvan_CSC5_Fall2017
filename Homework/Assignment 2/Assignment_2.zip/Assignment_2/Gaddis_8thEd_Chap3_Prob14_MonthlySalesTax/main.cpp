/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 24, 2017, 2:20 PM
 * Purpose: Calculating Monthly Sales Tax
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float sales,//Total sales made in the month
            sST,//State sales tax
            cST,//County sales tax
            totCol,//Total Collected that month
            totST,//total Sales tax
            year;
    string month;
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Enter the month and year"<<endl;
    cin>>month;
    cin>>year;
    cout<<"Enter the amount earned that month"<<endl;
    cin>>totCol;
    
    //Process or map the inputs to the outputs
    sales=totCol/1.06;//Calculation for the sales made that month
    cST=sales*.02;//Calculation for the county sales tax amount 
    sST=sales*.04;//Calculation for the state sales tax amount
    totST=sST+cST;//Calculations for the total sales tax amount
    
    //Display/Output all pertinent variables
    cout<<month<<" "<<year<<endl;
    cout<<"------------------"<<endl;
    cout<<"Total collected  $"<<totCol<<endl;
    cout<<"Sales"<<setw(13)<<"$"<<sales<<endl;
    cout<<"County Sales Tax $"<<cST<<endl;
    cout<<"State Sales Tax"<<setw(3)<<"$"<<sST<<endl;
    cout<<"Total Sales Tax"<<setw(3)<<"$"<<totST<<endl;
    
    //Exit the program
    return 0;
}