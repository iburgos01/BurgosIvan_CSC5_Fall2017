/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 24, 2017, 111:52 AM
 * Purpose: Calculating interest earned
 */

//System Libraries
#include <iostream>  //Input/output Stream Library

using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float CNVPERC=100;//Conversion for percentage
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float baseInc,//The base income earned/month
            ntype1,//Number of type 1 items sold 
            ntype2,//Number of type 2 items sold
            ntype3,//Number of type 3 items sold
            x,
            y,
            z,
            totAmt,//THe total amount earned
            incen;//Incentive rate 
    
    //Initialize Variables
    incen=1;//1%
    baseInc=3500;//$3500/month
    
    //Input Data/Variables
    cout<<"Enter the amount of $50 items sold "<<endl;
    cin>>ntype1;
    cout<<"Enter the amount of $100 items sold"<<endl;
    cin>>ntype2;
    cout<<"Enter the amount of $150 items sold"<<endl;
    cin>>ntype3;
    
    //Process or map the inputs to the outputs
    x=(ntype1*50)*(incen/CNVPERC);//Calculation for amount earned for $50 items sold
    y=(ntype2*100)*(incen/CNVPERC);//Calculation for the amount earned for $100 items sold
    z=(ntype3*150)*(incen/CNVPERC);//Calculation for the amount earned for $150 items sold
    totAmt=baseInc+x+y+z;//Calculation for total amount earned all together
    
    //Display/Output all pertinent variables
    cout<<"The base income per month = $"<<baseInc<<endl;
    cout<<"The number of $50 items sold = "<<ntype1<<endl;
    cout<<"The number of $100 items sold = "<<ntype2<<endl;
    cout<<"The number of $150 items sold = "<<ntype3<<endl;
    cout<<"The percentage of incentive given = "<<incen<<"%"<<endl;
    cout<<"The total amount earned all together = $"<<totAmt<<endl;
    
    //Exit the program
    return 0;
}