/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 24, 2017, 3:05 PM
 * Purpose: Word Game
 */

//System Libraries
#include <iostream> //Input/output Stream Library
#include <string>
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    string name,//Person's name
            age,//Person's age
            city,//City person lives in
            college,//College the person went to
            career,//Career the person has chosen
            animal,//Animal of the person's choice
            petName;//Name person would give to a pet
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Please enter your name"<<endl;
    getline(cin,name);
    cout<<"Please enter your age"<<endl;
    getline(cin,age);
    cout<<"Enter the city name"<<endl;
    getline(cin,city);
    cout<<"Enter name of college attending"<<endl;
    getline(cin,college);
    cout<<"Enter your profession"<<endl;
    getline(cin,career);
    cout<<"Enter an animal you like"<<endl;
    cin>>animal;
    cout<<"Enter a pet name"<<endl;
    cin>>petName;
        
    //Process or map the inputs to the outputs
    
    //Display/Output all pertinent variables
    cout<<"There once was a person named "<<name<<" who lived in "<<city;
    cout<<". At the age of"<<endl<<age<<", "<<name<<" went to college at "<<college;
    cout<<"."<<name<<" graduated and went to work"<<endl<<"as a "<<career<<".";
    cout<<"Then, "<<name<<" adopted a(n) "<<animal<<" named "<<petName<<". They"<<endl;
    cout<<"both lived happily ever after"<<endl;
    
    //Exit the program
    return 0;
}