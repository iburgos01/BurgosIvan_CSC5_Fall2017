/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 24, 2017, 3:41 PM
 * Purpose: Calculating slices of Pizza
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>
#include <iomanip>
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float PI=3.1415;//The constant value for pi

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float nSlice,//The number of slices per pizza
            dia,//the diameter of the pizza in inches
            rad,//the radius of the pizza in inches
            area;//the area of the pizza in inches
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Please enter the diameter of the pizza in inches"<<endl;
    cin>>dia;
    rad=dia/2;//Calculation to get the radius from diameter
    //Process or map the inputs to the outputs
    area=PI*pow(rad,2);//Calculation for the area of the pizza
    nSlice=area/14.125;//Calculation for the number of slices
    
    //Display/Output all pertinent variables
    cout<<"The diameter of the pizza = "<<dia<<" inches"<<endl;
    cout<<"The number of slices you can get = "<<setprecision(2)<<nSlice<<endl;
    
    //Exit the program
    return 0;
}