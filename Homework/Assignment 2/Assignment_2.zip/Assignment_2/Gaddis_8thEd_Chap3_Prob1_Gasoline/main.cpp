/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 24, 2017, 11:18 AM
 * Purpose: Calculating price of gasoline
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float CNVGLLT=4.546;//Conversion of gallons to liters

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float gas,//Amount of gas in liters
            pgas,//price for a certain amount gas in dollars
            ggas,//the amount of gas in gallons
            price;//The price of gas per gallon
    
    //Initialize Variables
    price=3.58;//$3.58 per gallon
    
    //Input Data/Variables
    cout<<"Input the amount of gas"<<endl;
    cin>>gas;
            
    //Process or map the inputs to the outputs
    ggas=gas/CNVGLLT;
    pgas=ggas*price;
    
    //Display/Output all pertinent variables
    cout<<"The price of gas per gallon = $"<<price<<endl;
    cout<<"The amount of gas in liters = "<<gas<<" liters"<<endl;
    cout<<"The amount of gas in gallons = "<<ggas<<" gl"<<endl;
    cout<<"THe price of the inputted amount of gas = $"<<pgas<<endl;
    
    //Exit the program
    return 0;
}