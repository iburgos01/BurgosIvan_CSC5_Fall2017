/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 24, 2017, 1:04 PM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream> //Input/output Stream Library
#include <cmath>

using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float PI=3.1415;//The constant value of pi
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float area,//The surface area of a cylinder
            volume,//The volume of a cylinder
            rad,//The radius of a cylinder
            hgt;//The height of a cylinder
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Enter the radius of the cylinder"<<endl;
    cin>>rad;
    cout<<"Enter the height of the cylinder"<<endl;
    cin>>hgt;
    
    //Process or map the inputs to the outputs
    area=2*PI*rad*hgt+2*PI*pow(rad,2);//Calculation for the area of a cylinder
    volume=PI*pow(rad,2)*hgt;//Calculation for the volume of a cylinder
    
    //Display/Output all pertinent variables
    cout<<"The radius of the cylinder = "<<rad<<endl;
    cout<<"The height of the cylinder = "<<hgt<<endl;
    cout<<"The area of the cylinder = "<<area<<endl;
    cout<<"The volume of the cylinder = "<<volume<<endl;
    
    //Exit the program
    return 0;
}