/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 9, 2017, 5:15 PM
 * Purpose: Age check 
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int month,//The month in numerical numbers
        year,//the year of the users choice
        day;//day of the users choice 
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Enter a month"<<endl;
    cin>>month;
    cout<<"Enter a day"<<endl;
    cin>>day;
    cout<<"Enter the last two numbers of a year"<<endl;
    cin>>year;
    
    //Process or map the inputs to the outputs
    if ((month*day)==year)
    {
        
        cout<<"The date is magic"<<endl;
        cout<<month<<"/"<<day<<"/"<<year<<endl;
    }
    else 
    {
        cout<<"The date is not magic"<<endl;
        cout<<month<<"/"<<day<<"/"<<year<<endl;
    }
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}