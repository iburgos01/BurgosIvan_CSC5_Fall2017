/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 9, 2017, 5:15 PM
 * Purpose: Age check 
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int curyr,//The current year
        biryr,//The birth year of the user
        age;//The age of the user    
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Enter the current year"<<endl;
    cin>>curyr;
    cout<<"Enter your birth year"<<endl;
    cin>>biryr;
            
    //Process or map the inputs to the outputs
    age=curyr-biryr;
    if (age>=18&&age<=28){
        
        cout<<"The age of the applicant = "<<age<<" yrs"<<endl;
        cout<<"The applicant is eligible"<<endl;
    }
    else 
    {
        cout<<"The age of applicant = "<<age<<"  yrs"<<endl;
        cout<<"The applicant is not eligible"<<endl;
    }
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}