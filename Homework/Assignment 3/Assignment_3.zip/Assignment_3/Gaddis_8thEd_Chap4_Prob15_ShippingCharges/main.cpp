/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 9, 2017, 2:15 PM
 * Purpose: Shipping Charges
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float weight,//Weight of the package in kg
          miles,//The amount of miles the package will travel
          price;
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Enter the weight of the package in kg"<<endl;
    cin>>weight;
    cout<<"Enter the amount of miles the package will travel"<<endl;
    cin>>miles;
            
    //Process or map the inputs to the outputs
    if ((weight>0&&weight<2)&&(miles>=10&&miles<=3000))
    {
        price=miles>=10&&miles<=500?1.10:
              miles>500&&miles<=1000?1.10*2:
              miles>1000&&miles<=1500?1.10*3:
              miles>1500&&miles<=2000?1.10*4:
              miles>2000&&miles<=2500?1.10*5:1.10*6;
    }
    else if((weight>2&&weight<=6)&&(miles>=10&&miles<=3000))
    {
         price=miles>=10&&miles<=500?2.20:
              miles>500&&miles<=1000?2.20*2:
              miles>1000&&miles<=1500?2.20*3:
              miles>1500&&miles<=2000?2.20*4:
              miles>2000&&miles<=2500?2.20*5:2.20*6;
    }
    else if((weight>6&&weight<=10)&&(miles>=10&&miles<=3000))
    {
         price=miles>=10&&miles<=500?3.70:
              miles>500&&miles<=1000?3.70*2:
              miles>1000&&miles<=1500?3.70*3:
              miles>1500&&miles<=2000?3.70*4:
              miles>2000&&miles<=2500?3.70*5:3.70*6;
    }
    else if((weight>10&&weight<=20)&&(miles>=10&&miles<=3000))
    {
          price=miles>=10&&miles<=500?4.80:
              miles>500&&miles<=1000?4.80*2:
              miles>1000&&miles<=1500?4.80*3:
              miles>1500&&miles<=2000?4.80*4:
              miles>2000&&miles<=2500?4.80*5:4.810*6;
    }
    else
    {    
         cout<<"The package does not meet the required weight and/or distance"<<endl;
         cout<<"The required weight must be between 0kg and 20kg"<<endl;
         cout<<"The required miles must between 0 miles and 3000 miles"<<endl;
    }
    //Display/Output all pertinent variables
    cout<<endl;
    cout<<"The weight of the package = "<<weight<<"kg"<<endl;
    cout<<"The distance the package will travel = "<<miles<<" miles"<<endl;
    cout<<"The price for shipping = $"<<price<<endl;
    
    //Exit the program
    return 0;
}