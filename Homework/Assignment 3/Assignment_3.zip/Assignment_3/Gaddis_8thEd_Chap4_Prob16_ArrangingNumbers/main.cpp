/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 9, 2017, 2:56 PM
 * Purpose: Arranging Random Numbers 
 */

//System Libraries
#include <iostream> //Input/output Stream Library
#include <cstdlib> //For rand and srand
#include <ctime>

using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    srand(static_cast<unsigned int>(time(0)));
    short x,y,z;
    
    //Initialize Variables
    
    //Input Data/Variables
    x=rand()%101;
    y=rand()%101;
    z=rand()%101;
    
    //Process or map the inputs to the outputs
    if (x>y&&y>z)
        cout<<x<<","<<y<<","<<z;
    else if (x>y&&y<z)
        cout<<x<<","<<z<<","<<y;
    else if (y>x&&x>z)
        cout<<y<<","<<x<<","<<z;
    else if (y>x&&x<z)
        cout<<y<<","<<z<<","<<x;
    else if (z>x&&x>y)
        cout<<z<<","<<x<<","<<y;
    else 
        cout<<z<<","<<y<<","<<x;
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}