/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 9, 2017, 5:47 PM
 * Purpose: Type of wave
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float wavlen;//The wavelength in meters
            
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Enter the length of the wave in meters"<<endl;
    cin>>wavlen;
            
    //Process or map the inputs to the outputs
    if(wavlen>0&&wavlen>=1e-2)
        cout<<"Radio wave"<<endl;
    else if (wavlen<1e-2&&wavlen>=1e-3)
        cout<<"Microwaves"<<endl;
    else if (wavlen<1e-3&&wavlen>=7e-7)
        cout<<"Infrared"<<endl;
    else if (wavlen<7e-7&&wavlen>=4e-7)
        cout<<"Visible Light"<<endl;
    else if (wavlen<4e-7&&wavlen>=1e-8)
        cout<<"Ultraviolet"<<endl;
    else if (wavlen<1e-8&&wavlen>=1e-11)
        cout<<"X-Rays"<<endl;
    else if (wavlen>1e-11)
        cout<<"Gamma Rays"<<endl; 
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}