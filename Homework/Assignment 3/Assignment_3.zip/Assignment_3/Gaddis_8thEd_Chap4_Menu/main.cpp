/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on August 29, 2017, 12:01 PM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cstdlib> //For rand and srand
#include <ctime>
#include <cmath>
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float PI=3.1415;//The constant for PI
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int choice;//The Choice made by the person
    
    //Initialize Variables
    cout<<"1.Gaddis_8thEd_Chap4_Prob2_AgeCheck"<<endl;
    cout<<"2.Gaddis_8thEd_Chap4_Prob3_MagicDate"<<endl;
    cout<<"3.Gaddis_8thEd_Chap4_Prob5_Roots"<<endl;
    cout<<"4.Gaddis_8thEd_Chap4_Prob12_SoftwareSales"<<endl;
    cout<<"5.Gaddis_8thEd_Chap4_Prob13_BookClub"<<endl;
    cout<<"6.Gaddis_8thEd_Chap4_Prob15_ShippingCharges"<<endl;
    cout<<"7.Gaddis_8thEd_Chap4_Prob16_ArrangingNumbers"<<endl;
    cout<<"8.Gaddis_8thEd_Chap4_Prob19_SpectralAnalysis"<<endl;
    cout<<"9.Gaddis_8thEd_Chap4_Prob23_GeometryCalc"<<endl;
    cout<<"Please enter choice from above list"<<endl;
    cin>>choice;
    //Input Data/Variables
    switch(choice)
    {
        case 1:
        {
    int month,//The month in numerical numbers
        year,//the year of the users choice
        day;//day of the users choice 
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Enter a month"<<endl;
    cin>>month;
    cout<<"Enter a day"<<endl;
    cin>>day;
    cout<<"Enter the last two numbers of a year"<<endl;
    cin>>year;
    
    //Process or map the inputs to the outputs
    if ((month*day)==year)
    {
        
        cout<<"The date is magic"<<endl;
        cout<<month<<"/"<<day<<"/"<<year<<endl;
    }
    else 
    {
        cout<<"The date is not magic"<<endl;
        cout<<month<<"/"<<day<<"/"<<year<<endl;
    }
        }
        break;
        case 2:{
             int curyr,//The current year
        biryr,//The birth year of the user
        age;//The age of the user    
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Enter the current year"<<endl;
    cin>>curyr;
    cout<<"Enter your birth year"<<endl;
    cin>>biryr;
            
    //Process or map the inputs to the outputs
    age=curyr-biryr;
    if (age>=18&&age<=28){
        
        cout<<"The age of the applicant = "<<age<<" yrs"<<endl;
        cout<<"The applicant is eligible"<<endl;
    }
    else 
    {
        cout<<"The age of applicant = "<<age<<"  yrs"<<endl;
        cout<<"The applicant is not eligible"<<endl;
    }
    break;
        }
        case 3:{
    float a,b,c;
    float ans;
    //Initialize Variables
  
    
    //Input Data/Variables
    cout<<"Enter a value for a "<<endl;
    cin>>a;
    cout<<"Enter a value for b"<<endl;
    cin>>b;
    cout<<"Enter a value for c"<<endl;
    cin>>c;
    //Process or map the inputs to the outputs
    ans=pow(b,2)-4*a*c;
    if (ans>0){
        cout<<a<<"x^2+"<<b<<"x+"<<c<<"= 0"<<endl;
        cout<<"The roots are real and unequal"<<endl;    
    }
    else if (ans==0){
        cout<<a<<"x^2+"<<b<<"x+"<<c<<"= 0"<<endl;
        cout<<"There is only one real root"<<endl;
    }
    else if (ans<0)
    {
        cout<<a<<"x^2+"<<b<<"x+"<<c<<"= 0"<<endl;
        cout<<"The roots are complex and unequal"<<endl;
    }
        }
            break;
        case 4:{
           
    //Declare Variables
    float sofSal, //The price of the software sold
          disc,//The Discount given to the price
          amtdisc,//The amount of the discount in $
          totpri,//The total price
          numSal;//The number of items been bought
    
    //Initialize Variables
    sofSal=99;
    
    //Input Data/Variables
    cout<<"Please enter the number of units been bought"<<endl;
    cin>>numSal;
    
    //Process or map the inputs to the outputs
    if (numSal>0&&numSal<10)
    {
        totpri=sofSal*numSal;
    }
    else if (numSal>=10&&numSal<=19)
    {
        disc=.2;
        amtdisc=sofSal*disc;
        totpri=(sofSal-amtdisc)*numSal;                
    }
    else if (numSal>=20&&numSal<=49)
    {
        disc=.3;
        amtdisc=sofSal*disc;
        totpri=(sofSal-amtdisc)*numSal;   
    }  
    else if (numSal>=50&&numSal<=99)
    {
        disc=.4;
        amtdisc=sofSal*disc;
        totpri=(sofSal-amtdisc)*numSal;
    }
        else if (numSal>=100)
            {
        disc=.5;
        amtdisc=sofSal*disc;
        totpri=(sofSal-amtdisc)*numSal;
          }
        //Display/Output all pertinent variables
            cout<<"The amount of units ordered = "<<numSal<<endl;
            cout<<"The discount given = "<<disc*100<<"%"<<endl;
            cout<<"The price of software = $"<<sofSal<<endl;
            cout<<"The total price = $"<<totpri<<endl;
        }
            break;
        case 5:{
             //Declare Variables
             int numbks,//The number of books bought in the month
                 points;//The number of points awarded
    
             //Initialize Variables
    
            //Input Data/Variables
             cout<<"Enter the number of books bought in the month"<<endl;
             cin>>numbks;
    
            //Process or map the inputs to the outputs
            if (numbks==0)
                points=0;
            else if (numbks==1)
                points=5;
            else if (numbks==2)
                points=15;
            else if (numbks==3)
                points=30;
            else if (numbks>=4)
                points=60;
            else 
                cout<<"Enter a valid number"<<endl;
                         
            //Display/Output all pertinent variables
            cout<<"The number of books bought in the month = "<<numbks<<" books"<<endl;
            cout<<"The number of points awarded = "<<points<<" points"<<endl;
        }
            break;
        case 6:{
           //Declare Variables
            float weight,//Weight of the package in kg
                    miles,//The amount of miles the package will travel
                    price;
    
          //Initialize Variables
    
          //Input Data/Variables
            cout<<"Enter the weight of the package in kg"<<endl;
            cin>>weight;
            cout<<"Enter the amount of miles the package will travel"<<endl;
            cin>>miles;
            
            //Process or map the inputs to the outputs
            if ((weight>0&&weight<2)&&(miles>=10&&miles<=3000))
            {
                price=miles>=10&&miles<=500?1.10:
                      miles>500&&miles<=1000?1.10*2:
                      miles>1000&&miles<=1500?1.10*3:
                      miles>1500&&miles<=2000?1.10*4:
                      miles>2000&&miles<=2500?1.10*5:1.10*6;
            }
           else if((weight>2&&weight<=6)&&(miles>=10&&miles<=3000))
            {
               price=miles>=10&&miles<=500?2.20:
                     miles>500&&miles<=1000?2.20*2:
                     miles>1000&&miles<=1500?2.20*3:
                     miles>1500&&miles<=2000?2.20*4:
                     miles>2000&&miles<=2500?2.20*5:2.20*6;
            }
           else if((weight>6&&weight<=10)&&(miles>=10&&miles<=3000))
            {
              price=miles>=10&&miles<=500?3.70:
                    miles>500&&miles<=1000?3.70*2:
                    miles>1000&&miles<=1500?3.70*3:
                    miles>1500&&miles<=2000?3.70*4:
                    miles>2000&&miles<=2500?3.70*5:3.70*6;
            }
           else if((weight>10&&weight<=20)&&(miles>=10&&miles<=3000))
            {
              price=miles>=10&&miles<=500?4.80:
                    miles>500&&miles<=1000?4.80*2:
                    miles>1000&&miles<=1500?4.80*3:
                    miles>1500&&miles<=2000?4.80*4:
                    miles>2000&&miles<=2500?4.80*5:4.810*6;
            }
           else
        {    
             cout<<"The package does not meet the required weight and/or distance"<<endl;
             cout<<"The required weight must be between 0kg and 20kg"<<endl;
             cout<<"The required miles must between 0 miles and 3000 miles"<<endl;
        }
         //Display/Output all pertinent variables
            cout<<endl;
            cout<<"The weight of the package = "<<weight<<"kg"<<endl;
            cout<<"The distance the package will travel = "<<miles<<" miles"<<endl;
            cout<<"The price for shipping = $"<<price<<endl; 
        }
            break;
        case 7:{
         //Declare Variables
        srand(static_cast<unsigned int>(time(0)));
        short x,y,z;
    
        //Initialize Variables
    
        //Input Data/Variables
        x=rand()%101;
        y=rand()%101;
        z=rand()%101;
    
        //Process or map the inputs to the outputs
        if (x>y&&y>z)
            cout<<x<<","<<y<<","<<z;
        else if (x>y&&y<z)
            cout<<x<<","<<z<<","<<y;
        else if (y>x&&x>z)
            cout<<y<<","<<x<<","<<z;
        else if (y>x&&x<z)
            cout<<y<<","<<z<<","<<x;
        else if (z>x&&x>y)
            cout<<z<<","<<x<<","<<y;
        else 
            cout<<z<<","<<y<<","<<x;
        }
            break;
        case 8:{
        //Declare Variables
        float wavlen;//The wavelength in meters
            
        //Initialize Variables
    
        //Input Data/Variables
            cout<<"Enter the length of the wave in meters"<<endl;
            cin>>wavlen;
            
        //Process or map the inputs to the outputs
        if(wavlen>0&&wavlen>=1e-2)
            cout<<"Radio wave"<<endl;
        else if (wavlen<1e-2&&wavlen>=1e-3)
            cout<<"Microwaves"<<endl;
        else if (wavlen<1e-3&&wavlen>=7e-7)
            cout<<"Infrared"<<endl;
        else if (wavlen<7e-7&&wavlen>=4e-7)
            cout<<"Visible Light"<<endl;
        else if (wavlen<4e-7&&wavlen>=1e-8)
            cout<<"Ultraviolet"<<endl;
        else if (wavlen<1e-8&&wavlen>=1e-11)
            cout<<"X-Rays"<<endl;
        else if (wavlen>1e-11)
            cout<<"Gamma Rays"<<endl;    
        }
            break;
        case 9:{
        //Declare Variables
        int choice;//The Choice made by the person
        float radius,//The radius of the circle
            length,//The length of the rectangle 
            width,//The width of the rectangle
            base,//The base length of the triangle
            height,//The height of the triangle
            area;//The area of the chosen object
    
        //Initialize Variables
    
        //Input Data/Variables
        cout<<"1.Calculate the area of a circle"<<endl;
        cout<<"2.Calculate the area of a rectangle"<<endl;
        cout<<"3.Calculate the area of a triangle"<<endl;
        cout<<"4.Quit"<<endl;
        cout<<"Please make a choice from above selection"<<endl;
        cin>>choice;
        //Process or map the inputs to the outputs
      switch (choice)
      {
        case 1:{
            cout<<"Enter the radius of the circle"<<endl;
               cin>>radius;
               if (radius>=0){ 
               area=PI*pow(radius,2);
               cout<<"The area of the circle = "<<area<<endl;
               }
               else
                   cout<<"Please enter a nonnegative number"<<endl;
               break;
        }
               
        case 2:
        {
            cout<<"Enter the length of the rectangle"<<endl;
               cin>>length;
               cout<<"Enter the width of the rectangle"<<endl;
               cin>>width;
               if (length>=0&&width>=0){
               area=length*width;
               cout<<"The area of the rectangle = "<<area<<endl;
               }
               else
                   cout<<"Please enter nonnegative numbers"<<endl;
        }
        break;
        case 3:{
            cout<<"Enter the height of the triangle"<<endl;
               cin>>height;
               cout<<"Enter the base of the triangle"<<endl;
               cin>>base;
               if(base>=0&&height>=0)
               {
               area=(base*height)*.5;
               cout<<"The area of the triangle = "<<area<<endl;
               }
               else
                   cout<<"Please enter a nonnegative number"<<endl;
        }
        break;
        case 4:break;
        default:cout<<"Please enter a number between 1 through 4"<<endl;
      }    
        }
        break;
        default:cout<<"Please enter a number from the list"<<endl;    
    }
    //Process or map the inputs to the outputs
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}