/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 9, 2017, 4:02 PM
 * Purpose: Calculating Software Sales
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float sofSal, //The price of the software sold
          disc,//The Discount given to the price
          amtdisc,//The amount of the discount in $
          totpri,//The total price
          numSal;//The number of items been bought
    
    //Initialize Variables
    sofSal=99;
    
    //Input Data/Variables
    cout<<"Please enter the number of units been bought"<<endl;
    cin>>numSal;
    
    //Process or map the inputs to the outputs
    if (numSal>0&&numSal<10)
    {
        totpri=sofSal*numSal;
    }
    else if (numSal>=10&&numSal<=19)
    {
        disc=.2;
        amtdisc=sofSal*disc;
        totpri=(sofSal-amtdisc)*numSal;                
    }
    else if (numSal>=20&&numSal<=49)
    {
        disc=.3;
        amtdisc=sofSal*disc;
        totpri=(sofSal-amtdisc)*numSal;   
    }  
    else if (numSal>=50&&numSal<=99)
    {
        disc=.4;
        amtdisc=sofSal*disc;
        totpri=(sofSal-amtdisc)*numSal;
    }
    else if (numSal>=100)
    {
        disc=.5;
        amtdisc=sofSal*disc;
        totpri=(sofSal-amtdisc)*numSal;
    }
    //Display/Output all pertinent variables
    cout<<"The amount of units ordered = "<<numSal<<endl;
    cout<<"The discount given = "<<disc*100<<"%"<<endl;
    cout<<"The price of software = $"<<sofSal<<endl;
    cout<<"The total price = $"<<totpri<<endl;
    //Exit the program
    return 0;
}