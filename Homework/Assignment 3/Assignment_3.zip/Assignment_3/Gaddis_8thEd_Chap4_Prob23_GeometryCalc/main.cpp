/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 9, 2017, 6:10 PM
 * Purpose: MAking a Geometry Calculator
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float PI=3.1415;//The constant for PI
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int choice;//The Choice made by the person
    float radius,//The radius of the circle
            length,//The length of the rectangle 
            width,//The width of the rectangle
            base,//The base length of the triangle
            height,//The height of the triangle
            area;//The area of the chosen object
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"1.Calculate the area of a circle"<<endl;
    cout<<"2.Calculate the area of a rectangle"<<endl;
    cout<<"3.Calculate the area of a triangle"<<endl;
    cout<<"4.Quit"<<endl;
    cout<<"Please make a choice from above selection"<<endl;
    cin>>choice;
    //Process or map the inputs to the outputs
      switch (choice)
      {
        case 1:{
            cout<<"Enter the radius of the circle"<<endl;
               cin>>radius;
               if (radius>=0){ 
               area=PI*pow(radius,2);
               cout<<"The area of the circle = "<<area<<endl;
               }
               else
                   cout<<"Please enter a nonnegative number"<<endl;
               break;
        }
               
        case 2:
        {
            cout<<"Enter the length of the rectangle"<<endl;
               cin>>length;
               cout<<"Enter the width of the rectangle"<<endl;
               cin>>width;
               if (length>=0&&width>=0){
               area=length*width;
               cout<<"The area of the rectangle = "<<area<<endl;
               }
               else
                   cout<<"Please enter nonnegative numbers"<<endl;
        }
        break;
        case 3:{
            cout<<"Enter the height of the triangle"<<endl;
               cin>>height;
               cout<<"Enter the base of the triangle"<<endl;
               cin>>base;
               if(base>=0&&height>=0)
               {
               area=(base*height)*.5;
               cout<<"The area of the triangle = "<<area<<endl;
               }
               else
                   cout<<"Please enter a nonnegative number"<<endl;
        }
        break;
        case 4:break;
        default:cout<<"Please enter a number between 1 through 4"<<endl;
      }
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}