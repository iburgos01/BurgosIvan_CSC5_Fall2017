/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 9, 2017, 4:30 PM
 * Purpose: Awarding book club points
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int numbks,//The number of books bought in the month
        points;//The number of points awarded
    
    //Initialize Variables
    
    //Input Data/Variables
    cout<<"Enter the number of books bought in the month"<<endl;
    cin>>numbks;
    
    //Process or map the inputs to the outputs
    if (numbks==0)
        points=0;
    else if (numbks==1)
        points=5;
    else if (numbks==2)
        points=15;
    else if (numbks==3)
        points=30;
    else if (numbks>=4)
        points=60;
    else 
        cout<<"Enter a valid number"<<endl;
                         
    //Display/Output all pertinent variables
    cout<<"The number of books bought in the month = "<<numbks<<" books"<<endl;
    cout<<"The number of points awarded = "<<points<<" points"<<endl;
    
    //Exit the program
    return 0;
}