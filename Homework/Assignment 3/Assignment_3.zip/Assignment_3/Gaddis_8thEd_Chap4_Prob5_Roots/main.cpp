/* 
 * File:   main.cpp
 * Author: Ivan Burgos 
 * Created on October 9, 2017, 6:55 PM
 * Purpose: Roots of a quadratic equation
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float a,b,c;
    float ans;
    //Initialize Variables
  
    
    //Input Data/Variables
    cout<<"Enter a value for a "<<endl;
    cin>>a;
    cout<<"Enter a value for b"<<endl;
    cin>>b;
    cout<<"Enter a value for c"<<endl;
    cin>>c;
    //Process or map the inputs to the outputs
    ans=pow(b,2)-4*a*c;
    if (ans>0){
        cout<<a<<"x^2+"<<b<<"x+"<<c<<"= 0"<<endl;
        cout<<"The roots are real and unequal"<<endl;    
    }
    else if (ans==0){
        cout<<a<<"x^2+"<<b<<"x+"<<c<<"= 0"<<endl;
        cout<<"There is only one real root"<<endl;
    }
    else if (ans<0)
    {
        cout<<a<<"x^2+"<<b<<"x+"<<c<<"= 0"<<endl;
        cout<<"The roots are complex and unequal"<<endl;
    }
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}