/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 13, 2017, 1:27 PM
 * Purpose: Surface area and Volume of sphere
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float PI=3.1415;

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float rad=8,//is the radius of a sphere in cm
     area,//is the surface area of a sphere
     vol;//volume of a sphere
    
    //Initialize Variables
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    area=4*PI*rad*2;
    vol=(4)*PI*rad;
            
    //Display/Output all pertinent variables
    cout<<"The radius of the sphere = "<<rad<<"cm"<<endl;
    cout<<"The surface area of the sphere = "<<area<<endl;
    cout<<"The volume of the sphere = "<<vol<<endl;
    
    //Exit the program
    return 0;
}