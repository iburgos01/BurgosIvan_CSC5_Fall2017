/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 17, 2017, 11:47 AM
 * Purpose: Finding total sales
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float CNVFTIN=12;//conversion from feet to inches
const float CNVINMM=25.4;//conversion from inches to millimeters

//Function Prototypes

//Execution Begins Here
int main(int argc, char**argv) {
    //Declare Variables
    float lenFt,//the length of a wire in FT
            x,//new length inches
          lenIn,//additional length of wire in inches
            y,//combined length in inches
          lenMm;//the length of the wire in inches  
            
    //Initialize Variables
    lenFt=9;//9 feet
    lenIn=8;//8 inches
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    x=lenFt*CNVFTIN;
    y=lenIn+x;
    lenMm=y*CNVINMM;
    
    //Display/Output all pertinent variables
    cout<<"The length of the wire is = "<<lenFt<<"feet "<<lenIn<<"inches"<<endl;
    cout<<"The Combined length inches = "<<y<<"inches"<<endl;
    cout<<"The length in millimeters = "<<lenMm<<"mm"<<endl;
    
    //Exit the program
    return 0;
}