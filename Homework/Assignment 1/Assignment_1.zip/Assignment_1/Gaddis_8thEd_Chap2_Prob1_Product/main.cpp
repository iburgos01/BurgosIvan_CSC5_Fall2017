/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 17, 2017, 12:01 PM
 * Purpose: Assigning variables
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char**argv) {
    //Declare Variables
    int x, //the variable 10 will be assigned to
        y, //the variable 20 will be assigned to
        z, //the variable 30 will be assigned to
        product; // the product of the three variables
    //Initialize Variables
    x=10;
    y=20;
    z=30;
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    product=x*y*z;
    //Display/Output all pertinent variables
    cout<<"The value of x ="<<x<<endl;
    cout<<"the value of y ="<<y<<endl;
    cout<<"the value of z ="<<z<<endl;
    cout<<"the product of these three ="<<product<<endl;
    
    //Exit the program
    return 0;
}