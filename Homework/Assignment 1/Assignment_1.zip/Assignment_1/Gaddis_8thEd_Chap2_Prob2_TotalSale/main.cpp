/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 17, 2017, 11:47 AM
 * Purpose: Finding total sales
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char**argv) {
    //Declare Variables
    float pctTS,//The percentage of total sales
          sales,//Sales made that year 
          TotSal;//Total sales by the east Coast Division
    
    //Initialize Variables
    pctTS=58;//58 percent
    sales=8.6e6;//8.6 million
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    TotSal=pctTS*sales/100;
    
    //Display/Output all pertinent variables
    cout<<"the percent of sales made by the East Coast Division = "<<pctTS<<"%"<<endl;
    cout<<"the Sales made that in the year = "<<sales<<endl;
    cout<<"the Total sales made by the East Coast Division = "<<TotSal<<endl;
    
    //Exit the program
    return 0;
}