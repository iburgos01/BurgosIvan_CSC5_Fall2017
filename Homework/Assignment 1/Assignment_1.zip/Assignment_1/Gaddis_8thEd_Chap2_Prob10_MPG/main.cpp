/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 13, 2017, 2:06 PM
 * Purpose: Calculate MPG
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float mpg;//Miles per Gallon
    float gal=15;//Gallons of gas
    float miles=375;//miles driven on tank of gas
    //Initialize Variables
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    mpg=miles/gal;
    
    //Display/Output all pertinent variables
    cout<<"the number of gallons the car can hold ="<<gal<<endl;
    cout<<"the miles the car can drive before refueling ="<<miles<<endl;
    cout<<"The miles per gallon the car gets = "<<mpg<<endl;
    
    //Exit the program
    return 0;
}