/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 17, 2017, 11:47 AM
 * Purpose: Finding total sales
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char**argv) {
    //Declare Variables
    float payAmt,//The amount payed every pay period in dollars 
          payPer,//The number of pay periods in weeks
          annPay;//The amount payed annually  
            
    //Initialize Variables
    payAmt=2200;//$2200
    payPer=26;//26 weeks
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    annPay=payAmt*payPer;
    
    //Display/Output all pertinent variables
    cout<<"The amount payed to the employee = $"<<payAmt<<endl;
    cout<<"The number of pay periods in a year = "<<payPer<<" weeks"<<endl;
    cout<<"The annual pay of the employee = $"<<annPay<<endl; 
    
    //Exit the program
    return 0;
}