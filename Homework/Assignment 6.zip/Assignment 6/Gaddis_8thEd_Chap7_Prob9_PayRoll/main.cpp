/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 28th, 2017, 2:10 PM
 * Purpose: Payroll for 7 employees
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Formatting Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=7;
    int empId[SIZE]={5658845,4520125,7895122,8777541,8451277,1302850,7580489};
    int hours[SIZE]={};
    float payRate[SIZE]={},
          grsPay[SIZE]={};
    
    //Initialize Variables
    cout<<"Please enter the number of hours worked by each employee"<<endl;
    for(int i=0;i<SIZE;i++){
        cin>>hours[i];
    }
    cout<<"Please enter the pay for each employee"<<endl;
    for(int i=0;i<SIZE;i++){
        cin>>payRate[i];
    }
    //Input Data/Variables
    for(int i=0;i<SIZE;i++){
        grsPay[i]=payRate[i]*hours[i];
    }

    
    //Process or map the inputs to the outputs
   
    
    //Display/Output all pertinent variables
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Table of Employees"<<endl;
    cout<<"Emp ID    hours   PayRate   Gross Pay"<<endl;
    for(int i=0;i<SIZE;i++){
        cout<<empId[i]<<setw(5)<<hours[i]<<setw(9)
            <<"$"<<payRate[i]<<setw(12)<<"$"<<grsPay[i]<<endl;
    }
    //Exit the program
    return 0;
}

