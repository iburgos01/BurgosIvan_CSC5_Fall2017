/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on Oct 18th, 2017, 9:05 AM
 * Purpose:  Menu with functions
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
#include <iomanip>      //Formatting Library
#include <cstdlib>      //Rand and Srand
#include <ctime>        //Time Function Library
#include <cmath>        //Math Library
using namespace std;    //Standard Name-space under which System Libraries reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants
const unsigned int MAXRAND=pow(2,31)-1;

//Function Prototypes
void prob1();
void prob2();
void prob3();
float pRand();  //[0,1]
float stdNorm();//Normal Distribution N(0,1)
float filAray(float [],int);
float mean(float [],int);
float stdDev(float [],int);
void menu();

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int choice;
    //Loop the Menu and Problems
    do{
        //Input Data/Variables
        menu();
        cin>>choice;
        //Process or map the inputs to the outputs
        switch(choice){
            case 1:prob1();break;
            case 2:prob2();break;
            case 3:prob3();break;
            default:{
                cout<<"Exiting, have a great day!"<<endl;
            }
        }
    }while(choice>0&&choice<4);
    //Exit the program
    return 0;
}

void prob1(){
   //Declare Variables
    const int SIZE=7;
    int empId[SIZE]={5658845,4520125,7895122,8777541,8451277,1302850,7580489};
    int hours[SIZE]={};
    float payRate[SIZE]={},
          grsPay[SIZE]={};
    
    //Initialize Variables
    cout<<"Please enter the number of hours worked by each employee"<<endl;
    for(int i=0;i<SIZE;i++){
        cin>>hours[i];
    }
    cout<<"Please enter the pay for each employee"<<endl;
    for(int i=0;i<SIZE;i++){
        cin>>payRate[i];
    }
    //Input Data/Variables
    for(int i=0;i<SIZE;i++){
        grsPay[i]=payRate[i]*hours[i];
    }

    
    //Process or map the inputs to the outputs
   
    
    //Display/Output all pertinent variables
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Table of Employees"<<endl;
    cout<<"Emp ID    hours   PayRate   Gross Pay"<<endl;
    for(int i=0;i<SIZE;i++){
        cout<<empId[i]<<setw(5)<<hours[i]<<setw(9)
            <<"$"<<payRate[i]<<setw(12)<<"$"<<grsPay[i]<<endl;
    }
}

void prob2(){
    //Declare Variables
    const int SIZE=20;
    int correct,wrong;//count how many are correct or wrong
    char ans[SIZE]={'A','D','B','B','C','B','A','B','C','D','A','C','D','B','D',
            'C','C','A','D','B'};//The correct answers to the exam
    char stuAns[SIZE]={};//Array storing the driver's answer
    int count[SIZE]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};//Number of the problems
    
    //Initialize Variables
    for (int i;i<SIZE;i++){
        do{
        cin>>stuAns[i];
        }while(stuAns[i]<65||stuAns[i]>69);
        if (stuAns[i]==ans[i])correct++;
        else wrong++;
    }
    //Input Data/Variables
    if (correct>=15){
        cout<<"Driver has Passed"<<endl;
        cout<<"Number of right answers "<<correct<<endl;
    }
    else {
        cout<<"Driver has failed"<<endl;
        cout<<"Number of wrong answers "<<wrong<<endl;
    }
    //Process or map the inputs to the outputs
    for (int i;i<SIZE;i++){
        if (stuAns[i]!=ans[i])
        cout<<count[i]<<endl;
    }
}

void prob3(){
    //Set the random Number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    const int SIZE=500000;
    float x[SIZE]={};
    
    //Initialize Variables
    filAray(x,SIZE);

    //Display/Output all pertinent variables
    cout<<"The simulated Normal Distribution = "
        <<"N("<<stdDev(x,SIZE)<<","<<mean(x,SIZE)
        <<")"<<endl;
    
}
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                     Random Probability
//Input:
//      x -> Array
//      n -> Size
//Output:
//      Fill The array with random standard normal values
//
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890


float filAray(float x[],int n){
    for(int i=0;i<n;i++){
        x[i]=stdNorm();
    }
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                                  Standard Deviation
//Input:
//      x->Array
//      n->Size
//Output:
//      Standard Deviation 
//
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890


float stdDev(float x[],int n){
    float sum=0;
    float xmean=mean(x,n);
    for(int i=0;i<n;i++){
        float delx=x[i]-xmean;
        sum+=(delx*delx);
    }
    return sqrt(sum/(n-1));
}
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                                     Mean
//Input:
//      x->Array
//      N->Size
//Output:
//      mean or average of array
//
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890

float mean(float x[],int n){
    float sum=0;
    for(int i=0;i<n;i++){
        sum+=x[i];
    }
    return sum/n;
}
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                     Standard Normal Probability
//Input:
//      None
//Output:
//      Standard Normal number between [-6,6]
//
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890

float stdNorm(){
    float sum=0;
    for (int i=1;i<=12;i++){
        sum+=pRand();
    }
    return sum-6;
}
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                     Random Probability
//Input:
//      None
//Output:
//      Pseudo-Random number between [0,1]
//
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890

float pRand(){
    //The maximum random number = 2^31-1
    static const float scale=1/(pow(2,31)-1);
    return rand()*scale;
}

void menu(){
    //Input Data/Variables
    cout<<"Choose from the Menu"<<endl;
    cout<<"1. Gaddis 8thEd Chap7 Prob 9"<<endl;
    cout<<"2. Gaddis 8thEd Chap7 Prob 10"<<endl;
    cout<<"3. Savitch 9thEd Chap7 Prob 20"<<endl;
}