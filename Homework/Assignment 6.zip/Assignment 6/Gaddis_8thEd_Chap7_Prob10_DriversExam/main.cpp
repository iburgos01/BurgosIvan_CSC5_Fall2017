/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 28th, 2017, 8:40 PM
 * Purpose: Storing number of salsas sold
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes


//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=20;
    int correct,wrong;//count how many are correct or wrong
    char ans[SIZE]={'A','D','B','B','C','B','A','B','C','D','A','C','D','B','D',
            'C','C','A','D','B'};//The correct answers to the exam
    char stuAns[SIZE]={};//Array storing the driver's answer
    int count[SIZE]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};//Number of the problems
    
    //Initialize Variables
    for (int i;i<SIZE;i++){
        do{
        cin>>stuAns[i];
        }while(stuAns[i]<65||stuAns[i]>69);
        if (stuAns[i]==ans[i])correct++;
        else wrong++;
    }
    //Input Data/Variables
    if (correct>=15){
        cout<<"Driver has Passed"<<endl;
        cout<<"Number of right answers "<<correct<<endl;
    }
    else {
        cout<<"Driver has failed"<<endl;
        cout<<"Number of wrong answers "<<wrong<<endl;
    }
    //Process or map the inputs to the outputs
    for (int i;i<SIZE;i++){
        if (stuAns[i]!=ans[i])
        cout<<count[i]<<endl;
    }
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

