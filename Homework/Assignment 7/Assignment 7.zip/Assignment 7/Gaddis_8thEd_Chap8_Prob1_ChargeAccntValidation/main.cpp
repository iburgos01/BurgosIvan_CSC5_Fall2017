/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on December 6th, 2017, 3:32 PM
 * Purpose: Checking for a valid account
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=18;//The size of the array
    int accnt[SIZE]={5658845,4520125,7895122,8777541,8451277,1302850,
                    8080152,4562555,5552012,5050552,7825877,1250255,
                    1005231,6545231,3852085,7576651,7881200,4581002};
    int acntNum;//Account been looked for by user
    //Initialize Variables
    cout<<"Enter an account number"<<endl;
    cin>>acntNum;
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    for(int i;i<SIZE;i++){
       if(acntNum==accnt[i])cout<<"The account "<<acntNum<<" is valid"<<endl;
       else cout<<"The account "<<acntNum<<" is invalid"<<endl;
               
    }
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

