/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on December 6th, 2017, 4:25 PM
 * Purpose:  Searching Winner number using Binary search  
 */

//System Libraries Here
#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
int bSearch(int [],int,int );//Checking the list of guessed lottery numbers  

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int SIZE=10;//The size of the array
    int gesNum[SIZE]={13579,26791,26792,33445,55555,62483,
                       77777,79422,85647,93121};//The list of guesses
    int winNum;//The winning lottery number of the week
    int index;
     
    //Input or initialize values Here
    cout<<"Enter the weeks winning number"<<endl;
    cin>>winNum;
            
    //Process/Calculations Here
    index=bSearch(gesNum,SIZE,winNum);
    //Output Located Here
    if(index==-1)cout<<"You did not win"<<endl;
    else cout<<"You win"<<endl;
    //Exit
    return 0;
}

int bSearch(int a[],int n,int val){
    int first=0,last=n-1,middle;
    do{
        middle=(last+first)/2;
        if(a[middle]==val){
            return middle;
        }else if(a[middle]>val){
            last=middle-1;
        }else{
            first=middle+1;
        }  
    }while(last>=first);
    return -1;
}