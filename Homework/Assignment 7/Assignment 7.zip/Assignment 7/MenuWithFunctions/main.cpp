/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on Oct 18th, 2017, 9:05 AM
 * Purpose:  Menu with functions
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
#include <iomanip>      //Formatting Library
#include <cstdlib>      //Rand and Srand
#include <ctime>        //Time Function Library
#include <cmath>        //Math Library
using namespace std;    //Standard Name-space under which System Libraries reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants
const unsigned int MAXRAND=pow(2,31)-1;

//Function Prototypes
void prob1();
void prob2();
void prob3();
void prob4();
void prob5();
void menu();
void check(int [],int,int );//Checking the list of guessed lottery numbers
int bSearch(int [],int,int );//Checking the list of guessed lottery numbers
int bubSort(int [],int);
int selSort(int[],int);
void filAray(int [],int);
void prtAray(int [],int,int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int choice;
    //Loop the Menu and Problems
    do{
        //Input Data/Variables
        menu();
        cin>>choice;
        //Process or map the inputs to the outputs
        switch(choice){
            case 1:prob1();break;
            case 2:prob2();break;
            case 3:prob3();break;
            case 4:prob4();break;
            case 5:prob5();break;
            default:{
                cout<<"Exiting, have a great day!"<<endl;
            }
        }
    }while(choice>0&&choice<6);
    //Exit the program
    return 0;
}

void prob1(){
  //Declare Variables
    const int SIZE=18;//The size of the array
    int accnt[SIZE]={5658845,4520125,7895122,8777541,8451277,1302850,
                    8080152,4562555,5552012,5050552,7825877,1250255,
                    1005231,6545231,3852085,7576651,7881200,4581002};
    int acntNum;//Account been looked for by user
    bool search=true;
    //Initialize Variables
    cout<<"Enter an account number"<<endl;
    cin>>acntNum;
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    for(int i;i<SIZE;i++){
       if(acntNum==accnt[i])cout<<"The account "<<acntNum<<" is valid"<<endl;
       else cout<<"The account "<<acntNum<<" is invalid"<<endl;
               
    }
    
    //Display/Output all pertinent variables
    
    //Exit the program
    
}

void prob2(){
 //Declare all Variables Here
    const int SIZE=10;//The size of the array
    int gesNum[SIZE]={13579,26791,26792,33445,55555,62483,
                       77777,79422,85647,93121};//The list of guesses
    int winNum;//The winning lottery number of the week
     
    //Input or initialize values Here
    cout<<"Enter the weeks winning number"<<endl;
    cin>>winNum;
            
    //Process/Calculations Here
    check(gesNum,SIZE,winNum);
    //Output Located Here  
}

void prob3(){
  //Declare all Variables Here
    const int SIZE=10;//The size of the array
    int gesNum[SIZE]={13579,26791,26792,33445,55555,62483,
                       77777,79422,85647,93121};//The list of guesses
    int winNum;//The winning lottery number of the week
    int index;
     
    //Input or initialize values Here
    cout<<"Enter the weeks winning number"<<endl;
    cin>>winNum;
            
    //Process/Calculations Here
    index=bSearch(gesNum,SIZE,winNum);
    //Output Located Here
    if(index==-1)cout<<"You did not win"<<endl;
    else cout<<"You win"<<endl;  
}

void prob4(){
    //Declare Variables
    const int SIZE=18;//The size of the array
    int accnt[SIZE]={5658845,4520125,7895122,8777541,8451277,1302850,
                    8080152,4562555,5552012,5050552,7825877,1250255,
                    1005231,6545231,3852085,7576651,7881200,4581002};
    int acntNum;//Account been looked for by user
    int index;
    //Initialize Variables
    cout<<"Enter an account number"<<endl;
    cin>>acntNum;
    
    //Input Data/Variables
    selSort(accnt,SIZE);
    //Process or map the inputs to the outputs
    index=bSearch(accnt,SIZE,acntNum);    
    //Display/Output all pertinent variables
    if (index==-1)cout<<"The account is invalid"<<endl;
    else cout<<"The account is valid"<<endl; 
}

void prob5(){
  //Set the random number seed
     srand(static_cast<unsigned int>(time(0)));
     
    //Declare Variables
    const int SIZE=20;//The size of the array
    int test[SIZE]={};//The array used to test the sorts
    int exchge;//The number of exchanges made
    
    //Initialize Variables
    filAray(test,SIZE);
    
    //Input Data/Variables
    prtAray(test,SIZE,10);
    //Process or map the inputs to the outputs
    cout<<endl;
    cout<<"The number of exchanges made by the bubble sort = "<<bubSort(test,SIZE)<<endl;
    
    prtAray(test,SIZE,10);
    
    cout<<endl;
    cout<<"New Array to be sorted"<<endl;
    //Display/Output all pertinent variables
    filAray(test,SIZE);
     
    prtAray(test,SIZE,10);
    
    cout<<endl;
    cout<<"The number of exchanges made by selection Sort = "
        <<selSort(test,SIZE)<<endl;
    
    prtAray(test,SIZE,10);  
}

void menu(){
    //Input Data/Variables
    cout<<"Choose from the Menu"<<endl;
    cout<<"1. Gaddis 8thEd Chap8 Prob 1"<<endl;
    cout<<"2. Gaddis 8thEd Chap8 Prob 2"<<endl;
    cout<<"3. Gaddis 8thEd Chap8 Prob 3"<<endl;
    cout<<"4. Gaddis 8thEd Chap8 Prob 4"<<endl;
    cout<<"5. Gaddis 8thEd Chap8 Prob 9"<<endl;
}

void check(int a[],int SIZE,int win){
    cout<<"Win Num    Guesses"<<endl;
    for(int i;i<SIZE;i++){
        cout<<win<<setw(12)<<a[i];
        if (a[i]==win)cout<<setw(10)<<"Winner"<<endl;
        else cout<<setw(10)<<"Loser"<<endl;      
   } 
}

int bSearch(int a[],int n,int val){
    int first=0,last=n-1,middle;
    do{
        middle=(last+first)/2;
        if(a[middle]==val){
            return middle;
        }else if(a[middle]>val){
            last=middle-1;
        }else{
            first=middle+1;
        }  
    }while(last>=first);
    return -1;
}

int selSort(int a[],int n){
    int exchge,minIdex,minVle;
    for (int i=0;i<n-1;i++){
        minIdex=i;
        minVle=a[i];
        for(int index=i+1;index<n;index++){
            if(a[index]<minVle){
                minVle=a[index];
                minIdex=index;
                exchge++;
            }
        }
        a[minIdex]=a[i];
        a[i]=minVle;
    }
    return exchge;
}

int bubSort(int a[],int n){
    int exchge=0;
    bool swp;
    do{
        swp=false;
        for(int j=0;j<n-1;j++){
            if(a[j]>a[j+1]){
                swap(a[j],a[j+1]);
                swp=true;
                exchge++;
            }
        }
    }while(swp);
    return exchge;
}

void swap(int &a,int &b){
    int temp=a;
    a=b;
    b=temp;
}

void prtAray(int test[],int SIZE,int perLine){
    cout<<endl;
    for (int i=0;i<SIZE;i++){
        cout<<test[i]<<" ";
       if(i%perLine==(perLine-1))cout<<endl; 
    }
}

void filAray(int test[],int SIZE){
    for (int i;i<SIZE;i++){
        test[i]=rand()%20+1;
    }
}