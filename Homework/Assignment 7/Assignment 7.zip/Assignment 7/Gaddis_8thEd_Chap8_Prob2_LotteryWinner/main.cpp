/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 30th, 2017, 11:30 AM
 * Purpose:  Searching Winner number using linear search  
 */

//System Libraries Here
#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library

using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
void check(int [],int,int );//Checking the list of guessed lottery numbers  

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int SIZE=10;//The size of the array
    int gesNum[SIZE]={13579,26791,26792,33445,55555,62483,
                       77777,79422,85647,93121};//The list of guesses
    int winNum;//The winning lottery number of the week
     
    //Input or initialize values Here
    cout<<"Enter the weeks winning number"<<endl;
    cin>>winNum;
            
    //Process/Calculations Here
    check(gesNum,SIZE,winNum);
    //Output Located Here

    //Exit
    return 0;
}

void check(int a[],int SIZE,int win){ 
    cout<<"Win Num    Guesses"<<endl;
    for(int i;i<SIZE;i++){
        cout<<win<<setw(12)<<a[i];
        if (a[i]==win)cout<<setw(10)<<"Winner"<<endl;
        else cout<<setw(10)<<"Loser"<<endl;      
   } 
}