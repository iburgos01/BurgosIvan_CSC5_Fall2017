/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on December 5th, 2017, 12:19 PM
 * Purpose:  Testing to number of exchanges made
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
#include <ctime>        //Time Library
#include <cstdlib>      //Srand and rand Library
using namespace std;    //Standard Name-space under which System Libraries reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes
void filAray(int [],int);
void prtAray(int [],int,int);
int bubSort(int [],int);
void swap(int &,int &);
int selSort(int [],int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
     srand(static_cast<unsigned int>(time(0)));
     
    //Declare Variables
    const int SIZE=20;//The size of the array
    int test[SIZE]={};//The array used to test the sorts
    int exchge;//The number of exchanges made
    
    //Initialize Variables
    filAray(test,SIZE);
    
    //Input Data/Variables
    prtAray(test,SIZE,10);
    //Process or map the inputs to the outputs
    cout<<endl;
    cout<<"The number of exchanges made by the bubble sort = "<<bubSort(test,SIZE)<<endl;
    
    prtAray(test,SIZE,10);
    
    cout<<endl;
    cout<<"New Array to be sorted"<<endl;
    //Display/Output all pertinent variables
    filAray(test,SIZE);
     
    prtAray(test,SIZE,10);
    
    cout<<endl;
    cout<<"The number of exchanges made by selection Sort = "
        <<selSort(test,SIZE)<<endl;
    
    prtAray(test,SIZE,10);
    
    //Exit the program
    return 0;
}

int selSort(int a[],int n){
    int exchge,minIdex,minVle;
    for (int i=0;i<n-1;i++){
        minIdex=i;
        minVle=a[i];
        for(int index=i+1;index<n;index++){
            if(a[index]<minVle){
                minVle=a[index];
                minIdex=index;
                exchge++;
            }
        }
        a[minIdex]=a[i];
        a[i]=minVle;
    }
    return exchge;
}

int bubSort(int a[],int n){
    int exchge=0;
    bool swp;
    do{
        swp=false;
        for(int j=0;j<n-1;j++){
            if(a[j]>a[j+1]){
                swap(a[j],a[j+1]);
                swp=true;
                exchge++;
            }
        }
    }while(swp);
    return exchge;
}

void swap(int &a,int &b){
    int temp=a;
    a=b;
    b=temp;
}


void prtAray(int test[],int SIZE,int perLine){
    cout<<endl;
    for (int i=0;i<SIZE;i++){
        cout<<test[i]<<" ";
       if(i%perLine==(perLine-1))cout<<endl; 
    }
}

void filAray(int test[],int SIZE){
    for (int i;i<SIZE;i++){
        test[i]=rand()%20+1;
    }
}