/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on December 6th, 2017, 3:32 PM
 * Purpose: Checking for a valid account
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants


//Function Prototypes
int bSearch(int [],int,int);//Binary search Function
void selSort(int[],int);
//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=18;//The size of the array
    int accnt[SIZE]={5658845,4520125,7895122,8777541,8451277,1302850,
                    8080152,4562555,5552012,5050552,7825877,1250255,
                    1005231,6545231,3852085,7576651,7881200,4581002};
    int acntNum;//Account been looked for by user
    int index;
    //Initialize Variables
    cout<<"Enter an account number"<<endl;
    cin>>acntNum;
    
    //Input Data/Variables
    selSort(accnt,SIZE);
    //Process or map the inputs to the outputs
    index=bSearch(accnt,SIZE,acntNum);    
    //Display/Output all pertinent variables
    if (index==-1)cout<<"The account is invalid"<<endl;
    else cout<<"The account is valid"<<endl;
    //Exit the program
    return 0;
}

void selSort(int a[],int n){
    int minIdex,minVle;
    for (int i=0;i<n-1;i++){
        minIdex=i;
        minVle=a[i];
        for(int index=i+1;index<n;index++){
            if(a[index]<minVle){
                minVle=a[index];
                minIdex=index;
            }
        }
        a[minIdex]=a[i];
        a[i]=minVle;
    }
}

int bSearch(int a[],int n,int val){
    int first=0,last=n-1,middle;
    do{
        middle=(last+first)/2;
        if(a[middle]==val){
            return middle;
        }else if(a[middle]>val){
            last=middle-1;
        }else{
            first=middle+1;
        }  
    }while(last>=first);
    return -1;
}