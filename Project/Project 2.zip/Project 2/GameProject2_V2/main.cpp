/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 4, 2017, 12:22 AM
 * Purpose: Guessing Game Project
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Formatting Library
#include <cmath>     //Used for math Properties
#include <cstdlib>   //USed for random nuber generator
#include <ctime>     //Used for srand
#include <string>    //For inputing sentences or names

using namespace std;//Standard Name-space under which system Libraries Reside 

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes
void menu(int,string);                   //Function used for the menu
void easy(int &,int &,string,short &);   //Function that runs easy difficulty
void medium(int &,int &,string,short &); //Function that runs medium difficulty
void hard(int &,int &,string,short &);   //Function that runs hard difficulty
void chllnge(int &,int &,string,short &);//Function the runs challenge mode
void swap(int &,int &);                  //Function to swap range

//Execution Begins Here
int main(int argc, char** argv) {
    //Setting the Random number seed
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables
    string name;                        //The player's name
    short choice;                       //User's choice in difficulty          
    
    //Initialize Variables
    cout<<"Enter your full name"<<endl;//Output to ask player's name
    getline(cin,name);                 //Inputing the user's name
    while(choice<=0||choice>=5){       //While loop checking for user input
    cout<<"Choose the difficulty"<<endl//Displaying the difficulties
        <<"1.Easy"<<endl               //Output Easy difficulty option
        <<"2.Normal"<<endl             //Output Normal difficulty option
        <<"3.Hard"<<endl               //Output Hard difficulty option
        <<"4.Challenge Mode"<<endl;    //Output Challenge mode option
    cin>>choice;                       //User inputs choice
    } 
    
    //Input user's choice
    menu(choice,name);                 //Call the menu function
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    
    //Display/Output all pertinent variables
    cout<<"Thank you "<<name<<" for playing the game"<<endl;
    //Exit the program
    return 0;
}

void chllnge(int &a,int &b,string c,short &d){
    const int SIZE=20;
        int array[SIZE]={},                                               //Array for the number of guesses values  
            anum[SIZE]={};                                                //Array for the random number values  
        int rnum,                                                         //random number to be guessed
            guess;                                                        //User's guess
        char ans;
        bool loop=true;                                                        //Used to enter and exit do-while loop
        d=0;
            cout<<"You have chosen challenge mode"<<endl
                <<",will be given 8 guesses as your limit"<<endl
                <<",and have a range from 1 to 540"<<endl<<endl;
            a=1;
            b=540;//User input of the ranges
            do{                                                          //do while 
            rnum=(rand()%(b-a+1))+a;                                     //number to be generated
            do{                                                          //do-while loop used to allow player to make guesses
                cout<<"Please enter your guess"<<endl;
                cin>>guess;                                              //User input for the guess 
                if (guess<rnum)cout<<"You are to low"<<endl;             //Hint stating lower that random number
                else if(guess>rnum)cout<<"You are to high"<<endl;        //Hint stating higher than random number
                if (guess==rnum){                                        //If statement showing player has won game 
                    cout<<"You have guessed the correct number "<<rnum<<endl
                        <<c<<" has won the game"<<endl
                        <<"Number of guesses made "<<d<<endl;
                    cout<<"Would you like to keep going?(Y=yes,N=no)"<<endl;
                    cin>>ans;
                    if (ans!="Y"||ans!="y")exit(0);                    //exits the function if player wants to stop 
                    loop=false;                                         //Used to exit the loop by using booleans
                }
                else if (d==8){                                         //If statement showing player has lost game
                    cout<<"You are out of guesses "<<d<<endl
                        <<c<<" have lost "<<endl
                        <<"Correct number "<<rnum<<endl;    
                    loop=false;                                        //Used to exit the loop by using booleans
                }
                d++;
            }while(loop);
            if (d==8)loop=true;
            for(int i;i<SIZE;i++){
                array[i]=d;
                cout<<array[i];
                anum[i]=rnum;
                cout<<setw(5)<<anum[i]<<endl;                
            }                                
        }while(!loop);
}
            

void hard(int &a,int &b,string c,short &d){
        int rnum,                                                    //random number to be guessed
            guess;                                                   //User's guess
            cout<<"You have chosen Hard difficulty"<<endl
                <<"and will be given 10 guesses as your limit"<<endl
                <<"but your ranges will be doubled"<<endl;    
            bool loop;                                              //Used to enter and exit the do-while 
            cout<<"Please enter values for range"<<endl;
            cin>>a>>b;                                              //User input of the ranges
            a=a*2;
            b=b*2;
            abs(a);
            abs(b);
            if (a>b)swap(a,b);                                     //Calls the swap function if a>b 
            rnum=(rand()%(b-a+1))+a;                               //number to be generated
            do{                                                    //Do-while to keep game going till out of guesses
                loop=true;
                cout<<"Please enter your guess"<<endl;
                cin>>guess;                                        //User input for the guess 
                d++;
                if (guess<rnum)cout<<"You are to low"<<endl;      //Hints letting player know they are lower 
                else if(guess>rnum)cout<<"You are to high"<<endl; //Hints letting player know they are higher
                if (guess==rnum){                                 //If statement showing player has won game
                    cout<<"You have guessed the correct number "<<rnum<<endl
                        <<c<<" has won the game"<<endl
                        <<"Number of guesses made "<<d<<endl;
                    loop=false;                                   //Used to exit the loop by using booleans
                }
                else if (d==10){                                  //If statement showing player has lost game
                    cout<<"You are out of guesses "<<d<<endl
                        <<c<<" have lost "<<endl
                        <<"Correct number "<<rnum<<endl;    
                    loop=false;                                  //Used to exit the loop by using booleans
                }   
            }while(loop);
}
void medium(int &a,int &b,string c,short &d){  //Runs medium difficulty function
        int rnum,                                                       //random number to be guessed
            guess;                                                      //User's guess
            cout<<"You have chosen normal difficulty"<<endl
                <<"and will be given 6 guesses as your limit"<<endl;
            bool loop;                                                 //Used to enter and exit the do-while 
            cout<<"Please enter values for range"<<endl;
            cin>>a>>b;                                                 //User input of the ranges
            abs(a);
            abs(b);
            if (a>b)swap(a,b);                                         //Calls the swap function if a>b 
            rnum=(rand()%(b-a+1))+a;                                   //number to be generated
            do{    
                loop=true;
                cout<<"Please enter your guess"<<endl;
                cin>>guess;                                           //User input for the guess 
                d++;
                if (guess<rnum)cout<<"You are to low"<<endl;          //Hints to let player know they are lower 
                else if(guess>rnum)cout<<"You are to high"<<endl;     //Hints to let player know they are higher
                if (guess==rnum){                                     //If statement showing player has won game
                    cout<<"You have guessed the correct number"<<rnum<<endl
                        <<c<<"has won the game"<<endl
                        <<"Number of guesses made "<<d<<endl;
                    loop=false;                                      //Used to exit the loop by using booleans
                }
                else if (d==6){                                      //If statement showing player has lost game
                    cout<<"You are out of guesses "<<d<<endl
                        <<c<<" have lost "<<endl
                        <<"Correct number "<<rnum<<endl;    
                    loop=false;                                      //Used to exit the loop by using booleans
                }   
            }while(loop);
}

void easy(int &a,int &b,string c,short &d){
    int rnum,                                                    //random number to be guessed
        guess;                                                   //User's guess
    cout<<"You have chosen easy difficulty"<<endl
                <<"and will be given 8 guesses as your limit"<<endl;   
            bool loop;                                           //Used to enter and exit the do-while 
            cout<<"Please enter values for range"<<endl;
            cin>>a>>b;                                           //User input of the ranges
            abs(a);
            abs(b);
            if (a>b)swap(a,b);
            rnum=(rand()%(b-a+1))+a;                             //number to be generated
            do{                                                  //Do-while used to allow player to make guesses
                loop=true;
                cout<<"Please enter your guess"<<endl;
                cin>>guess;                                      //User input for the guess 
                d++;
                if (guess<rnum)cout<<"You are to low"<<endl;     //Hint stating lower that random number
                else if(guess>rnum)cout<<"You are to high"<<endl;//Hint stating higher than random number
                if (guess==rnum){                                //If statement showing player has won game 
                    cout<<"You have guessed the correct number"<<rnum<<endl
                        <<c<<"has won the game"<<endl
                        <<"Number of guesses made"<<d<<endl;
                    loop=false;                                 //Used to exit the loop by using booleans
                }
                else if (d==8){                                 //If statement showing player has lost game
                    cout<<"You are out of guesses "<<d<<endl
                        <<c<<" have lost "<<endl
                        <<"Correct number "<<rnum<<endl;    
                    loop=false;                                 //Used to exit the loop by using booleans
                }   
            }while(loop);        
}

void menu(int a,string b){
    int nrnge1=0,   //First number in the range 
        nrnge2=0;   //Second number in the range
    short nguess=0; //The number of guesses the player starts with
  switch(a)         //the menu for choosing your difficulty
    {
        case 1:easy(nrnge1,nrnge2,b,nguess);break;   //Call First choice easy difficulty    
        case 2:medium(nrnge1,nrnge2,b,nguess);break; //Call Second choice normal difficulty
        case 3:hard(nrnge1,nrnge2,b,nguess);break;   //Call Third choice hard difficulty
        case 4:chllnge(nrnge1,nrnge2,b,nguess);break;//Call Forth choice challenge mode    
        
    }
}

void swap(int &a,int &b){  //Used to switch values
    int temp=a;            //Set temp = a value
        a=b;               //Set a = b value  
        b=temp;            //Set b = temp value  
}

