/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on December 12th, 2017, 12:22 PM
 * Purpose: Guessing Game Project
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //Formatting Library
#include <cmath>     //Used for math Properties
#include <cstdlib>   //USed for random nuber generator
#include <ctime>     //Used for srand
#include <string>    //For inputing sentences or names
#include <fstream>   //File stream Library 

using namespace std;//Standard Name-space under which system Libraries Reside 

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes
void menu(int,string);                   //Function used for the menu
void game(int &,int &,string,short &);   //Function that runs game mode
void chllnge(int &,int &,string,short &);//Function the runs challenge mode
void swap(int &,int &);                  //Function to swap range
int filAray(int[],int);                  //Function to fill array
void selSort(int [],int);                //Function that sorts using Selection sort
void bubSort(int[],int);                 //Function that sorts using Bubble sort
void prtAray(int[],int);                 //Function prints array to file
int bSearch(int[],int,int);              //Function that searches for a value
//Execution Begins Here
int main(int argc, char** argv) {
    //Setting the Random number seed
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables
    string name;                        //The player's name
    short choice;                       //User's choice in difficulty          
    
    //Initialize Variables
    cout<<"Enter your full name"<<endl;//Output to ask player's name
    getline(cin,name);                 //Inputing the user's name
    while(choice<=0||choice>3){        //While loop checking for user input
    cout<<"Choose a mode"<<endl        //Displaying the different modes
        <<"1.Game mode"<<endl          //Output Game mode option
        <<"2.Challenge Mode"<<endl;    //Output Challenge mode option
    cin>>choice;                       //User inputs choice
    } 
    
    //Input user's choice
    menu(choice,name);                 //Call the menu function
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    
    //Display/Output all pertinent variables
    cout<<"Thank you "<<name<<" for playing the game"<<endl;
    //Exit the program
    return 0;
}

void chllnge(int &a,int &b,string c,short &d){
    const int SIZE=50;                                                   //Size of the array 
        int array[SIZE]={},                                              //Array for the random number of values
                i;                                                       //Place of the array value
        int rnum,                                                        //random number to be guessed
            guess,                                                       //User's guess
            num;                                                         //The number the player inputs to choose a sort
        char ans;
        bool loop=true;                                                  //Used to enter and exit do-while loop
        d=0;
            filAray(array,SIZE);
            while(num<=0||num>=11){
               cout<<"Please chose a number between 1 and 10"<<endl;     //Prompt user for a number between 1 and 10         
               cin>>num;                                                 //Input number
            }
               if (num%2==0)selSort(array,SIZE);                         //If even number use Selection Sort
               else bubSort(array,SIZE);                                 //Else use bubble sort
            bSearch(array,SIZE,rnum);
            cout<<"You have chosen challenge mode"<<endl                 //Output rules of challenge mode
                <<",will be given 8 guesses as your limit"<<endl
                <<",and have a range from 1 to 540"<<endl<<endl;
            do{                                                          //Do-while that lets player continue to play
                i=(rand()%(49-1+1)+1);                                   //Randomly selects an i value
                rnum=array[i];                                           //Set random number equal to array at i
            do{                                                          //do-while loop used to allow player to make guesses
                cout<<"Please enter your guess"<<endl;                   //Prompt user for guess
                cin>>guess;                                              //User input for the guess 
                if (guess<rnum)cout<<"You are to low"<<endl;             //Hint stating lower that random number
                else if(guess>rnum)cout<<"You are to high"<<endl;        //Hint stating higher than random number
                if (guess==rnum){                                        //If statement showing player has won game 
                    cout<<"You have guessed the correct number "<<rnum<<endl
                        <<c<<" has won the game"<<endl
                        <<"Number of guesses made "<<d<<endl;
                    loop=false;                                          //Used to exit the loop by using booleans
                }
                else if (d==8){                                          //If statement showing player has lost game
                    cout<<"You are out of guesses "<<d<<endl
                        <<c<<" have lost "<<endl
                        <<"Correct number "<<rnum<<endl;    
                    loop=false;                                         //Used to exit the loop by using booleans
                }
                d++;
            }while(loop);
            prtAray(array,SIZE);
            if(guess==rnum){
            cout<<"Would you like to keep going?(Y=yes,N=no)"<<endl;    //Ask player if they would like to continue playing
            cin>>ans;                                                   //Player input answer
            if (ans=='Y'||ans=='y')loop=true;                           //Used to exit the loop by using booleans
            }
        }while(loop);
}

void game(int &a,int &b,string c,short &d){
    int rnum,                                                    //random number to be guessed
        guess,                                                   //User's guess
        choice,                                                  //Player's choice of difficulty 
        limges;                                                  //Limit the player has to guess
    cout<<"Please choose a difficulty"<<endl                     //Prompt player to difficulty  
            <<"1.Easy"<<endl                                     //Output easy difficulty   
            <<"2.Medium"<<endl                                   //Output medium difficulty
            <<"3.Hard"<<endl;                                    //Output hard difficulty   
    cin>>choice;
    switch(choice){
        case 1:{                                                 //Output the rules for easy difficulty
            cout<<"You have chosen easy difficulty"<<endl
                <<"and will be given 8 guesses as your limit"<<endl;
            cout<<"Please enter values for range"<<endl;
            cin>>a>>b;                                           //User input of the ranges
            limges=8;                                            //Set limit of guesses equal to 8
        }break;
        case 2:{
            cout<<"You have chosen normal difficulty"<<endl      //Output the rules for medium difficulty
                <<"and will be given 6 guesses as your limit"<<endl;
            cout<<"Please enter values for range"<<endl;
            cin>>a>>b;                                           //User input of the ranges
            limges=6;                                            //Set limit of guesses equal to 6
        }
        case 3:{
            cout<<"You have chosen Hard difficulty"<<endl        //Output the rules for hard difficulty
                <<"and will be given 10 guesses as your limit"<<endl
                <<"but your ranges will be doubled"<<endl;
            cout<<"Please enter values for range"<<endl;
            cin>>a>>b;                                           //User input of the ranges
            limges=10;                                           //Set limit of guesses equal to 10
            a*=2;                                                //Double the range of a and b
            b*=2;
        }break;
    }
            bool loop;                                           //Used to enter and exit the do-while
            abs(a);
            abs(b);
            if (a>b)swap(a,b);
            rnum=(rand()%(b-a+1))+a;                             //number to be generated
            do{                                                  //Do-while used to allow player to make guesses
                loop=true;
                cout<<"Please enter your guess"<<endl;
                cin>>guess;                                      //User input for the guess 
                d++;
                if (guess<rnum)cout<<"You are to low"<<endl;     //Hint stating lower that random number
                else if(guess>rnum)cout<<"You are to high"<<endl;//Hint stating higher than random number
                if (guess==rnum){                                //If statement showing player has won game 
                    cout<<"You have guessed the correct number"<<rnum<<endl
                        <<c<<"has won the game"<<endl
                        <<"Number of guesses made"<<d<<endl;
                    loop=false;                                  //Used to exit the loop by using booleans
                }
                else if (d==limges){                             //If statement showing player has lost game
                    cout<<"You are out of guesses "<<d<<endl
                        <<c<<" have lost "<<endl
                        <<"Correct number "<<rnum<<endl;    
                    loop=false;                                 //Used to exit the loop by using booleans
                }   
            }while(loop);        
}

void menu(int a,string b){
    int nrnge1=0,   //First number in the range 
        nrnge2=0;   //Second number in the range
    short nguess=0; //The number of guesses the player starts with
  switch(a)         //the menu for choosing your difficulty
    {
        case 1:game(nrnge1,nrnge2,b,nguess);break;   //Call First choice game mode   
        case 2:chllnge(nrnge1,nrnge2,b,nguess);break;//Call Second choice challenge mode    
       default:cout<<"Please make a choice between game and challenge mode"<<endl; //Output to player saying to choose an option
    }
}

void swap(int &a,int &b){  //Used to switch values
    int temp=a;            //Set temp = a value
        a=b;               //Set a = b value  
        b=temp;            //Set b = temp value  
}

int filAray(int a[],int n){
    for(int i=0;i<n;i++){
        a[i]=(rand()%(540-1+1))+1;
    }
}

void selSort(int a[],int n){
    int minIdex,minVle;         //the min value and min index
    for (int i=0;i<n-1;i++){    //For loop that searches for min value and index
        minIdex=i;              //Set  min index equal to zero
        minVle=a[i];            //Set min value equal to low array value 
        for(int index=i+1;index<n;index++){
            if(a[index]<minVle){
                minVle=a[index];
                minIdex=index;
            }
        }
        a[minIdex]=a[i];
        a[i]=minVle;
    }
}

void bubSort(int a[],int n){
    bool swp;
    do{
        swp=false;
        for(int j=0;j<n-1;j++){
            if(a[j]>a[j+1]){
                swap(a[j],a[j+1]);
                swp=true;
            }
        }
    }while(swp);
}

void prtAray(int a[],int n){            //Run print array function
    ofstream out;                       //Declare out as ofstream 
    out.open("array.txt");              //Open file and name
    out<<"List of Random Numbers"<<endl;//Output to file
    for(int i=0;i<n;i++){               //For loop to display array in file                      
        out<<*(a+i)<<endl;              //Output array to file
    }
    out.close();                        //Close file
}

int bSearch(int a[],int n,int val){  //Run binary search
    int first=0,last=n-1,middle;     //The first last and middle values
    do{                              //Do-while loop use while last >=first
        middle=(last+first)/2;       //Find the middle value in the array
        if(a[middle]==val){          //if the value is equal to the middle value
            return middle;
        }else if(a[middle]>val){     //if middle value is greater than value   
            last=middle-1;           //set equal to last= middle - 1
        }else{                       //else set first equal to middle+1
            first=middle+1;
        }  
    }while(last>=first);            
    return -1;
}