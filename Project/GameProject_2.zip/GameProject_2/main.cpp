/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 4, 2017, 12:22 AM
 * Purpose: Guessing Game Project
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <cmath>//Used for math Prperties
#include <cstdlib>//USed for random nuber generator
#include <ctime>//Used for srand
#include <string>//For inputing sentences or names
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes
void menu(int);
void easy(int &,int &,string,int);
void medium(int &,int &,string,int);
void hard(int &,int &,string,int );
void chllnge(int &,int &,string,int);
//Execution Begins Here
int main(int argc, char** argv) {
    //Setting the Random number seed
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables
    string name;
    short choice;   //User's choice in difficulty          
    
    //Initialize Variables
    cout<<"Enter your full name"<<endl;//Output to ask player's name
    getline(cin,name);                 //Inputing the user's name
    while(choice<=0||choice>=4){       //While loop checking for user input
    cout<<"Choose the difficulty"<<endl//Displaying the difficulties
        <<"1.Easy"<<endl               //Output Easy difficulty option
        <<"2.Normal"<<endl             //Output Normal difficulty option
        <<"3.Hard"<<endl               //Output Hard difficulty option
        <<"4.Challenge Mode"<<endl;    //Output Challenge mode option
    cin>>choice;                       //User inputs choice
    } 
    
    //Input user's choice
    menu(choice);                      //Call the menu function
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    
    //Display/Output all pertinent variables
    cout<<"Thank you"<<name<<"for playing the game"<<endl;
    //Exit the program
    return 0;
}

void chllnge(int &a,int b&,string &c,int d){
    int rnum,       //random number to be guessed
        guess;      //User's guess
    cout<<"You have chosen easy difficulty"<<endl
                <<"and will be given 8 guesses as your limit"<<endl;   
            bool loop;//Used to enter and exit the do-while 
            cout<<"Please enter values for range"<<endl;
            cin>>a>>b;//User input of the ranges
            abs(a);
            abs(b);
            rnum=(rand()%(b-a+1))+a;//number to be generated
            do{    //Do-while used to allow player to make guesses
                loop=true;
                cout<<"Please enter your guess"<<endl;
                cin>>guess;//User input for the guess 
                nguess++;
                if (guess<rnum)cout<<"You are to low"<<endl;//Hint stating lower that random number
                else if(guess>rnum)cout<<"You are to high"<<endl;//Hint stating higher than random number
                if (guess==rnum){//If statement showing player has won game 
                    cout<<"You have guessed the correct number"<<rnum<<endl
                        <<c<<"has one the game"<<endl
                        <<"Number of guesses made"<<d<<endl;
                    loop=false;//Used to exit the loop by using booleans
                }
                else if (d==8){//If statement showing player has lost game
                    cout<<"You are out of guesses "<<d<<endl
                        <<c<<" have lost "<<endl
                        <<"Correct number "<<rnum<<endl;    
                    loop=false;                         //Used to exit the loop by using booleans
                }   
            }while(loop);   
}

void hard(int &a,int &b,string c,int &d){
    int rnum,       //random number to be guessed
        guess;      //User's guess
    cout<<"You have chosen Hard difficulty"<<endl
                <<"and will be given 10 guesses as your limit"<<endl
                <<"but your ranges will be squared"<<endl;    
            bool loop;//Used to enter and exit the do-while 
            cout<<"Please enter values for range"<<endl;
            cin>>a>>b;//User input of the ranges
            a=a*2;
            b=b*2;        
            rnum=(rand()%(b-a+1))+a;//number to be generated
            do{    //Do-while to keep game going till out of guesses
                loop=true;
                cout<<"Please enter your guess"<<endl;
                cin>>guess;//User input for the guess 
                d++;
                if (guess<rnum)cout<<"You are to low"<<endl;
                else if(guess>rnum)cout<<"You are to high"<<endl;
                if (guess==rnum){//If statement showing player has won game
                    cout<<"You have guessed the correct number "<<rnum<<endl
                        <<c<<" has one the game"<<endl
                        <<"Number of guesses made "<<d<<endl;
                    loop=false;//Used to exit the loop by using booleans
                }
                else if (d==10){//If statement showing player has lost game
                    cout<<"You are out of guesses "<<d<<endl
                        <<c<<" have lost "<<endl
                        <<"Correct number "<<rnum<<endl;    
                    loop=false;//Used to exit the loop by using booleans
                }   
            }while(loop);
}
void medium(int &a,int &b,string c){
    int rnum,       //random number to be guessed
        guess;      //User's guess
    cout<<"You have chosen normal difficulty"<<endl
                <<"and will be given 6 guesses as your limit"<<endl;
            bool loop;//Used to enter and exit the do-while 
            cout<<"Please enter values for range"<<endl;
            cin>>a>>b;//User input of the ranges
            abs(a);
            abs(b);
            rnum=(rand()%(b-a+1))+a;//number to be generated
            do{    
                loop=true;
                cout<<"Please enter your guess"<<endl;
                cin>>guess;//User input for the guess 
                nguess++;
                if (guess<rnum)cout<<"You are to low"<<endl;
                else if(guess>rnum)cout<<"You are to high"<<endl;
                if (guess==rnum){//If statement showing player has won game
                    cout<<"You have guessed the correct number"<<rnum<<endl
                        <<c<<"has one the game"<<endl
                        <<"Number of guesses made "<<nguess<<endl;
                    loop=false;//Used to exit the loop by using booleans
                }
                else if (nguess==6){//If statement showing player has lost game
                    cout<<"You are out of guesses "<<nguess<<endl
                        <<c<<" have lost "<<endl
                        <<"Correct number "<<rnum<<endl;    
                    loop=false;//Used to exit the loop by using booleans
                }   
            }while(loop);
}

void easy(int &a,int &b,string c,int d){
    int rnum,       //random number to be guessed
        guess;      //User's guess
    cout<<"You have chosen easy difficulty"<<endl
                <<"and will be given 8 guesses as your limit"<<endl;   
            bool loop;//Used to enter and exit the do-while 
            cout<<"Please enter values for range"<<endl;
            cin>>a>>b;//User input of the ranges
            abs(a);
            abs(b);
            rnum=(rand()%(b-a+1))+a;//number to be generated
            do{    //Do-while used to allow player to make guesses
                loop=true;
                cout<<"Please enter your guess"<<endl;
                cin>>guess;//User input for the guess 
                nguess++;
                if (guess<rnum)cout<<"You are to low"<<endl;//Hint stating lower that random number
                else if(guess>rnum)cout<<"You are to high"<<endl;//Hint stating higher than random number
                if (guess==rnum){//If statement showing player has won game 
                    cout<<"You have guessed the correct number"<<rnum<<endl
                        <<c<<"has one the game"<<endl
                        <<"Number of guesses made"<<nguess<<endl;
                    loop=false;//Used to exit the loop by using booleans
                }
                else if (d==8){//If statement showing player has lost game
                    cout<<"You are out of guesses "<<nguess<<endl
                        <<c<<" have lost "<<endl
                        <<"Correct number "<<rnum<<endl;    
                    loop=false;                         //Used to exit the loop by using booleans
                }   
            }while(loop);        
}

void menu(int a){
    string name;    //For the users name
    int nrnge1=0,   //First number in the range 
        nrnge2=0;   //Second number in the range
    short nguess=0; //The number of guesses the player starts with
  switch(a)         //the menu for choosing your difficulty
    {
        case 1:easy(nrnge1,nrnge2,name,nguess);break;   //Call First choice easy difficulty    
        case 2:medium(nrnge1,nrnge2,name,nguess);break; //Call Second choice normal difficulty
        case 3:hard(nrnge1,nrnge2,name,nguess);break;   //Call Third choice hard difficulty
        case 4:chllnge(nrnge1,nrnge2,name,nguess);break;//Call Forth choice challenge mode    
        
    }
}