/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 16th, 2017, 11:49 AM
 * Purpose:  Car Calculator Version 3 MVC
 */

//System Libraries Here
#include <iostream>//Input/Output Library
#include <iomanip>//Formatting Libary
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
const int CNVMNYR=12;
const int CNVPERC=100;
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int SIZE=37;
    float pPrice,mnPmt,pDown,intRate,loan;
    int srtMon,byMon[SIZE];
    float intAccm[SIZE]={},loanAmt[SIZE]={};
    int nMonths;
    
    //Initialize values Here
    pPrice=10000.00f;         //Purchase Price = $350k
    intRate=0.05f;             //Interest Rate / Year 5%
    pDown=0.0f;                //Percentage Down = 20%
    mnPmt=299.71f;            //Monthly Payment = $1503.11
    loan=pPrice*(1-pDown);  //Calculate Loan Amount $'s
    nMonths=36;               //Number of Months in Loan Payment
    srtMon=0;                  //The Starting Month
    
    //Process or map the inputs to the outputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Home Amortization Table"<<endl;
    cout<<"Purchase Price  = $"<<pPrice<<endl;
    cout<<"Percent Down    =      "<<pDown*CNVPERC<<"%"<<endl;
    cout<<"Loan Amount     = $"<<loan<<endl;
    cout<<"Interest Rate   =      "<<intRate*CNVPERC<<"%"<<endl;
    cout<<"Monthly Payment =   $"<<mnPmt<<endl<<endl;
    cout<<"Month     Loan Amount  Int Paid    Monthly Payment"<<endl;
    int month=0;
    for(month=0;month<SIZE;month++){
        byMon[month]=month+srtMon;
        intAccm[month]=intRate*loan/CNVMNYR;//Interest Accrued per Month
        loanAmt[month]=loan;
        loan+=(intAccm[month]-mnPmt);
    }
    //Output Located Here
    for(month=0;month<SIZE;month++){
        cout<<setw(4)<<byMon[month]<<setw(16)<<loanAmt[month]<<setw(11)
                <<intAccm[month]<<setw(15)<<mnPmt<<endl;
    }
    cout<<endl;
    cout<<"Last Payment = $"<<(mnPmt+loanAmt[month])<<endl;
    cout<<"Total Paid for Loan = $"<<nMonths*mnPmt+loanAmt[month]<<endl;
    cout<<"Total Paid for Home = $"<<pPrice*pDown+nMonths*mnPmt+loanAmt[month]<<endl;
    //Exit the program
    return 0;
}

