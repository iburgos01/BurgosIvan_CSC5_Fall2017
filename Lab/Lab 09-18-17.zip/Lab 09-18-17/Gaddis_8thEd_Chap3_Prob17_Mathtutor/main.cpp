/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 19, 2017, 11:25 AM
 * Purpose: Calculate Monthly Payments
 */

//System Libraries
#include <iostream> //Input/output Stream Library
#include <cmath>
#include <iomanip>
#include <cstdlib>
#include <ctime>
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) 
{
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables
    unsigned short op1,op2,stuAns,result;
    
    //Initialize Variables
    op1=rand()%900+100;
    op2=rand()%900+100;
    
    //Input Data/Variables
    cout<<"the program tests your addition capablity"<<endl;
    cout<<"Type the answer"<<endl;
    cout<<setw(6)<<op1<<endl;
    cout<<"+"<<setw(5)<<op2<<endl;
    cout<<"------"<<endl;
    cin>>stuAns;
    
    //Process or map the inputs to the outputs
    result=op1+op2;
    
    //Display/Output all pertinent variables
    cout<<"The result "<<result<<endl;
    cout<<((result==stuAns)?"Correct":"Incorrect")<<endl;
            
    //Exit the program
    return 0;
}