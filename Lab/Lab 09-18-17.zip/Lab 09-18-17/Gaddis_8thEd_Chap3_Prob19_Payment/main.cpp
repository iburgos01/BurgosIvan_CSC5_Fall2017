/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 19, 2017, 11:25 AM
 * Purpose: Calculate Monthly Payments
 */

//System Libraries
#include <iostream> //Input/output Stream Library
#include <cmath>
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float CNVMTYR=12;
const float CNVPERC=100;
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) 
{
    //Declare Variables
    float  monPay, //the monthly payments in $
      intRate,//Percentage of interest rate
      loanAmt,//Loan amount
      nCPer,//Number of months
      totPay,//Total monthly payments
      totInt;//      
    
    //Initialize Variables
    nCPer=36;//36 months
    loanAmt=1e4f;//$10000
    intRate=1.2e1f;//12%
    
    //Input Data/Variables
    intRate/=(CNVMTYR*CNVPERC);
    
    //Process or map the inputs to the outputs
    float temp=pow(1+intRate,nCPer);//Calculations for the pow equation
    monPay=(intRate*temp)/(temp-1)*loanAmt;//Calculation for the monthly payments
    totPay=monPay*nCPer;//Calculations for total payments
    totInt=totPay-loanAmt;//Calculations for total interest paid
    
    //Display/Output all pertinent variables
    cout<<"The number of months = "<<nCPer<<" months"<<endl;
    cout<<"The interest rate = "<<intRate*CNVPERC<<"%"<<endl;
    cout<<"The loan amount is = $"<<loanAmt<<endl;
    cout<<"The monthly payments = $"<<monPay<<endl;
    cout<<"The total pay = $"<<totPay<<endl;
    cout<<"The total interest pay = $"<<totInt<<endl;
    
    //Exit the program
    return 0;
}