/*
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 17th, 2017, 11:55 AM
 * Purpose:  Weight Problem
 */

//System Libraries Here
#include <iostream>//Input/Output Stream Library
#include <cmath> //Absolute Value Library 
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
const float GRAVITY=6.673e-8f;//Universal Gravitational Constant
const float CNVCMFT=1/30.48f; //30.48 cm/ft
const float CNVMIFT=5280.0f;    //5280 ft/mile
const float CNVGKG=1000.0f;   //1000 grams to 1 kilogram
const float REARTH=3959.0f;   //Radius of the Earth
const float MEARTH=5.972e24f; //Mass of the Earth 
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
   float myMass, myWgt, actWgt;
   //Initialize Variables
   myMass=6.0f;
         
    //Input or initialize values Here
    cout<<"This program converts your weight in lbs to "<<endl;
    cout<<"Your mass in slugs"<<endl;
    cout<<"Input your actual weight in lbs"<<endl;
    cin>>actWgt;
    
    //Process/Calculations Here
    float delta,tol=.001f;
    float kGain=tol;
    do{
    myWgt=GRAVITY*CNVCMFT*CNVCMFT*CNVCMFT*MEARTH*CNVGKG*myMass/
            (REARTH*REARTH*CNVMIFT*CNVMIFT);
    delta=actWgt-myWgt;
    myMass+=kGain*delta;
    }while(abs(delta)>=tol);
    //Output Located Here
    cout<<"Your weight = "<<myWgt<<" lbs"<<endl;
    cout<<"Your mass   = "<<myMass<<" slugs"<<endl;
    
    //Exit
    return 0;
}

