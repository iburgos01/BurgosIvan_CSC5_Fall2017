/*
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 17th, 2017, 12:30 PM
 * Purpose:  Inflation Calculator
 */

//System Libraries Here
#include <iostream>//Input/Output Stream Library
#include <cmath> //Absolute value Library
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int yrNow=2017, yrThen;
    float infRate,prNow,prThen;
    
    //Initialize Variables
            
    //Input or initialize values Here
    cout<<"This program calculates inflation rate "<<endl;
    cout<<"Year and Price of Original Item"<<endl;
    cout<<"as well as price today"<<endl;
    cin>>yrThen>>prThen>>prNow;
    
    //Process/Calculations Here        
    infRate=.09f;
    float delta,tol=.001,prCalc;
    float kGain=.001;    
    do{
        prCalc=prThen;
        for(int year=yrThen+1;year<=yrNow;year++){
            prCalc*=(1+infRate);
        }
        delta=prNow-prCalc;
        infRate+=kGain*delta;
    }while(abs(delta)>=tol);
    //Output Located Here
    cout<<"In "<<yrThen<<" the price = $"<<prThen<<endl;
    cout<<"In "<<yrNow<<" then price = $"<<prNow<<endl;
    cout<<"The Price calculated = $"<<prCalc<<endl;
    cout<<"The Inflation Rate = "<<infRate*100<<"%"<<endl;
    //Exit
    return 0;
}

