/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 14th, 2017, 11:15 AM
 * Purpose:  Home Calculator Version 1
 */

//System Libraries Here
#include <iostream>//Input/Output Library
#include <iomanip>//Formatting Libary
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
const int CNVMNYR=12;
const int CNVPERC=100;
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int SIZE=360;
    float pPrice,mnPmt,pDown,intRate;
    int srtMon,byMon[SIZE];
    float intAccm[SIZE]={},loanAmt;
    int nMonths;
    
    //Initialize values Here
    pPrice=350000.00f;         //Purchase Price = $350k
    intRate=0.05f;             //Interest Rate / Year 5%
    pDown=0.2f;                //Percentage Down = 20%
    mnPmt=1503.11f;            //Monthly Payment = $1503.11
    loanAmt=pPrice*(1-pDown);  //Calculate Loan Amount $'s
    nMonths=360;               //Number of Months in Loan Payment
    srtMon=0;                  //The Starting Month
    
    //Process or map the inputs to the outputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Home Amortization Table"<<endl;
    cout<<"Purchase Price  = $"<<pPrice<<endl;
    cout<<"Percent Down    =      "<<pDown*CNVPERC<<"%"<<endl;
    cout<<"Loan Amount     = $"<<loanAmt<<endl;
    cout<<"Interest Rate   =       "<<intRate*CNVPERC<<"%"<<endl;
    cout<<"Monthly Payment =   $"<<mnPmt<<endl<<endl;
    cout<<"Month     Loan Amount  Int Paid    Monthly Payment"<<endl;
    int month=0;
    for(month=0;month<SIZE;month++){
        byMon[month]=month+srtMon;
        intAccm[month]=intRate*loanAmt/CNVMNYR;//Interest Accrued per Month
        cout<<setw(4)<<byMon[month]<<setw(16)<<loanAmt<<setw(11)
                <<intAccm[month]<<setw(15)<<mnPmt<<endl;
        loanAmt+=(intAccm[month]-mnPmt);
    }
    cout<<endl;
    cout<<"Last Payment = $"<<(mnPmt+loanAmt)<<endl;
    cout<<"Total Paid for Loan = $"<<nMonths*mnPmt+loanAmt<<endl;
    cout<<"Total Paid for Home = $"<<pPrice*pDown+nMonths*mnPmt+loanAmt<<endl;
    //Exit the program
    return 0;
}

