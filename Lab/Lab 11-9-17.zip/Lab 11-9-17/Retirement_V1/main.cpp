/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 9th, 2017, 12:15 PM
 * Purpose:  Retirement Calculator Version 1
 */

//System Libraries Here
#include <iostream>//Input/Output Library
#include <iomanip>//Formatting Libary
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float salary,deposit,invRate,savings,retAcct;
    
    //Initialize values Here
    salary=100000;         //$100k
    invRate=0.05f;         //5%
    savings=salary/invRate;//Required savings to retire $'s
    deposit=0.10f;         //10%/year
    retAcct=0;             //Initialize the Retirement account
    
    //Process or map the inputs to the outputs
    cout<<"Retirement Table"<<endl;
    cout<<"Year       Savings  Int Earned      Deposit"<<endl;
    cout<<fixed<<setprecision(2)<<showpoint;
    for(int year=2022;year<=2072;year++){
        float intErnd=invRate*retAcct;//Interest earned for the year
        float depAmt=deposit*salary;  //Yearly Deposit
        cout<<setw(4)<<year<<setw(13)<<retAcct<<setw(11)<<intErnd
                <<setw(15)<<depAmt<<endl;
        retAcct+=(intErnd+depAmt);      
        
    }
    
    //Exit the program
    return 0;
}

