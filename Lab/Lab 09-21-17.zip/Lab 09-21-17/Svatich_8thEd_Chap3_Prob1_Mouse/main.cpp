/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 21, 2017, 11:20 AM
 * Purpose: Calculating amount of cans of soft drink to kill person
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants
const float CNVGRAV=453.5;//The constant of gravity in lbs/grams
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) 
{
    //Declare Variables
    float massPer,//The mass of a person in lbs.
           conLev,//Concentration level of can of coke
           massMou,//the mass of a mouse in grams
           massCan,//the mass of a can of coke in grams
           mKM, //the mass of sweetner required to kill mouse in grams
           nKP;//the numbers of cans required to kill person 
    
    //Initialize Variables
    massMou=35;//35 grams
    massCan=350;//350 grams
    mKM=5;//5 grams
    conLev=.001;//is 1/10 of 1%
    
    //Input Data/Variables
    cout<<"Please enter your weight"<<endl;
    cin>>massPer;
    
    //Process or map the inputs to the outputs
    nKP=(massPer*(mKM/massMou))/(massCan*conLev)*CNVGRAV;
    
    //Display/Output all pertinent variables
    cout<<"The mass of a mouse = "<<massMou<<" grams"<<endl;
    cout<<"The mass of sweetner required to kill mouse = "<<mKM<<" grams"<<endl;
    cout<<"The mass of a can of coke = "<<massCan<<"grams"<<endl;
    cout<<"The concentration level of a can of coke = "<<conLev*100<<"%"<<endl;
    cout<<"The mass of the person = "<<massPer<<" lbs"<<endl;
    cout<<"The number of cans required to kill person = "<<nKP<<" cans"<<endl;
    //Exit the program
    return 0;
}