/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on August 31, 2017, 12:10 AM
 * Purpose:  Output a Tirangle
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    
    //Input or initialize values Here
   
    //Process/Calculations Here
   
            
    //Output Located Here
    cout<<"   *"<<endl;
    cout<<"  ***"<<endl;
    cout<<" *****"<<endl;
    cout<<"*******"<<endl;
    
    cout<<endl;
    cout<<"   *\n";
    cout<<"  ***\n";
    cout<<" *****\n";
    cout<<"*******\n";
    
    cout<<endl;
    cout<<"   ";
    cout<<"*"<<endl;
    cout<<"  ";
    cout<<"***"<<endl;
    cout<<" ";
    cout<<"*****"<<endl;
    cout<<"*******"<<endl;
    

    //Exit
    return 0;
}

