/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on August 31, 2017, 12:35 AM
 * Purpose:  Stock Purchase
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    short nShrs;//Number of shares of stock
    float ppShr,fee;//Pricer per share in $/share and fee as a percentage
    //Share cost in $'s, Commission Paid in $'s, Total Paid in $'s
    float shrCost,comPaid,totPaid;
    //Input or initialize values Here
    nShrs=750;
    ppShr=35;
    fee=2;
    
    //Process/Calculations Here
    shrCost=nShrs*ppShr;
    comPaid=shrCost*fee/100;
    totPaid=shrCost+comPaid;

    //Output Located Here
     cout<<"Number of Shares = "<<nShrs<<endl;
     cout<<"Share Price = $"<<ppShr<<"/share"<<endl;
     cout<<"Comission fee = "<<fee<<"%"<<endl;
     cout<<"Cost of Shares = $"<<shrCost<<endl;
     cout<<"Comission Paid = $"<<comPaid<<endl;
     cout<<"Total amount paid = $"<<totPaid<<endl;
             
          
    //Exit
    return 0;
}

