/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on August 29, 2017, 12:01 PM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    short a,b,c;
    
    //Initialize Variables
    a=200;
    b=300;
    
    //Process or map the inputs to the outputs
    c=a+b;
    
    //Display/Output all pertinent variables
    cout<<a<<" + "<<b<<" = "<<c<<endl;
    
    //Exit the program
    return 0;
}