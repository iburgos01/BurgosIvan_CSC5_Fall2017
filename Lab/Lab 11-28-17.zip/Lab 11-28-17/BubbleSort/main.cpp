/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on Nov 28th, 2017, 12:10 PM
 * Purpose:  Bubble Sort Implementation
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
#include <cstdlib>      //Random Function Library
#include <ctime>        //Set random number seed with time
using namespace std;    //Standard Name-space under which System Libraries reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes
void bubSort(int [],int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    const int SIZE=100;
    int array[SIZE];
    
    //Initialize Variables
    
    //Print the Array
    
    //Process or map the inputs to the outputs
    bubSort(array,SIZE);
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

void bubSort(int a[],int n){
    int perLine=10;
    for(int i=0;i<n;i++){
        a[i]=rand()%90+10;
    }
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
    bool swp;
    do{
        swp=false;
        for(int j=0;j<n-1;j++){
            if(a[j]>a[j+1]){
                int temp=a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;
                swp=true;
            }
        }
    }while(swp);
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
}

