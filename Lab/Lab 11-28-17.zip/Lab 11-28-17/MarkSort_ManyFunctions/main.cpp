/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on Nov 28th, 2017, 11:45 AM
 * Purpose:  Sorting with a Conquer and Divide Technique
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
#include <cstdlib>      //Random Function Library
#include <ctime>        //Set random number seed with time
using namespace std;    //Standard Name-space under which System Libraries reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes
void mrkSort(int [],int,int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    const int SIZE=100;
    int array[SIZE];
    
    //Initialize Variables
    
    //Print the Array
    
    //Process or map the inputs to the outputs
    mrkSort(array,SIZE,10);
    
    //Display/Output all pertinent variables
    //Exit the program
    return 0;
}

void mrkSort(int a[],int n,int perLine){
    int j=0;
    for(int i=0;i<n;i++){
        a[i]=rand()%90+10;
    }
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
    for(int i=0;i<n-1;i++){
       for(int i=j+1;i<n;i++){
        if(a[j]>a[i]){
            int temp=a[j];
                a[j]=a[i];
                a[i]=temp;
            }
        }
    }
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
}
