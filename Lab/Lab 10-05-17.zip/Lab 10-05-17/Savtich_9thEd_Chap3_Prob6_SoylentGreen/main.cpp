/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 5, 2017, 11:47 AM
 * Purpose: Soylent Green
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
#include <iomanip>   //
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int fi, fim1,fim2,counter;
    int wtCrud=10;//5 lbs of crud to start
    int deltDys=5;//5 Days between increments
    
    //Initialize Variables
    fim1=fim2=1; //initialize the sequence
    counter=1;  //Start with 3rd term in the sequence
    
    //Table Header
    cout<<"   Sequence    Crud Wt     N Days"<<endl;
    
    //Process or map the inputs to the outputs
    //First Row
    cout<<setw(10)<<fim2<<setw(10)<<wtCrud*fim2
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Second Row
    cout<<setw(10)<<fim1<<setw(10)<<wtCrud*fim1
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;        
    //Third Row
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Fourth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
   //Fifth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1; 
    //Sixth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Seventh Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Eighth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Ninth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Tenth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Eleventh Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Twelfth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Thirteenth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //Fourteenth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    //nth Row
    fim2=fim1;
    fim1=fi;
    fi=fim1+fim2;
    cout<<setw(10)<<fi<<setw(10)<<wtCrud*fi
          <<setw(10)<<(counter-1)*deltDys<<endl;
    counter+=1;
    
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}