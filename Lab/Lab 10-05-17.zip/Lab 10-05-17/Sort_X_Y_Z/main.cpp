/* 
 * File:   main.cpp
 * Author: Diego Hernandez
 * Created on August 29, 2017, 12:01 PM
 * Purpose: Creating our class template
 */

//System Libraries
#include <iostream>  //Input/output Stream Library
using namespace std; //Standard Name-space under which system Libraries Reside

//User Libraries

//Global Constants - No variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int x,y,z;
    
    //Initialize Variables
 
    //Input Data/Variables
    cout<<"Enter the value for x ";
    cin>>x;
    cout<<"Enter the value for y ";
    cin>>y;
    cout<<"Enter the value for z ";
    cin>>z;
    //Process or map the inputs to the outputs
    if (x>y&&y>z)
        cout<<x<<","<<y<<","<<z;
    else if (x>y&&y<z)
        cout<<x<<","<<z<<","<<y;
    else if (y>x&&x>z)
        cout<<y<<","<<x<<","<<z;
    else if (y>x&&x<z)
        cout<<y<<","<<z<<","<<x;
    else if (z>x&&x>y)
        cout<<z<<","<<x<<","<<y;
    else 
        cout<<z<<","<<y<<","<<x;
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}