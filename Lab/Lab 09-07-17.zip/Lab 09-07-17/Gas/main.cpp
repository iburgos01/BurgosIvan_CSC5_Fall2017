/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 5, 2017, 11:37 AM
 * Purpose:  Gas
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float ft=0.184f, // Federal Tax
            pp=2.93f,//Price at the pump for a gallon of gas
            st=.36f,//State Tax per Gallon $/Gallon
            pt=.0775f,//State percentage sales tax
            oc=0.07;// Oil Company Profit per Gallon
    float bp,//Base Price per gallon $/gallon
            tt,//Total Tax per gallon $/gallon
            ptt,//Percentage total tax
            ptp,//Percentage oil company profit
            sst;//State Sales Tax
    //Input or initialize values Here
   
    
    //Process/Calculations Here
    bp=(pp-ft-st)/(1+pt);
    sst=bp*pt;
    tt=pp-bp;
    ptt=tt/bp*100;
    ptp=oc/bp*100;
        
    //Output Located Here
    cout<<"Price at pump for a gallon of gas =$"<<pp<<endl;
    cout<<"Federal Tax per gallon of gas     =$"<<ft<<endl;
    cout<<"State Tax per gallon of gas       =$"<<st<<endl;
    cout<<"State percentage sales tax        = "<<pt*100<<"%"<<endl;
    cout<<"Oil company Profits per Gallon    =$"<<oc<<endl;
    cout<<"Computed Values"<< endl;
    cout<<"Base Price for a gallon of gas    ="<<bp<<endl;
    cout<<"State Sales Tax                   ="<<sst<<"%"<<endl;
    cout<<"Total tax per gallon of gas       ="<<tt<<endl;
    cout<<"Perecentage of total tax          ="<<ptt<<"%"<<endl;
    cout<<"Percentage total oil comp profit  ="<<ptp<<"%"<<endl;
         

    //Exit
    return 0;
}

