/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 12, 2017, 12:30 PM
 * Purpose:  Energy Drinks
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float custSrv=16500;//Number of customers Surveyed
    float pctSrv=.15;// Percentage of energy drinkers
    float pctCit=.58;// Percentage of citrus drinkers
    //Unknown Values 
    float nEneDrk;//Number of energy drinkers
    float nCitDrk;//Number that prefer citrus flavor
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    nEneDrk=custSrv*pctSrv;//Number of Energy Drinkers
    nCitDrk=nEneDrk*pctCit;//Number of Citrus Drinkers
    
    //Output Located Here
    cout<<"The Number of Customers Surveyed = "<<custSrv<<endl;
    cout<<"Percent of Energy Drinkers ="<<pctSrv*100<<"%"<<endl;
    cout<<"Percent of Citrus Drinkers ="<<pctCit*100<<"%"<<endl;
    cout<<"Number of Energy Drinkers  ="<<nEneDrk<<endl;
    cout<<"Number of Citrus Drinkers  ="<<nCitDrk<<endl;
    

    //Exit
    return 0;
}

