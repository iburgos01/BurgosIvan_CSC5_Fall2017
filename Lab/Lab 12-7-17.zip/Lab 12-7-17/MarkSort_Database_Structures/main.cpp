/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on Nov 27th, 2017, 8:30 AM
 * Purpose:  Sorting as with a database
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
#include <cstdlib>      //Random Function Library
#include <ctime>        //Set random number seed with time
using namespace std;    //Standard Name-space under which System Libraries reside

//User Libraries
#include "Field.h"
//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes
void filAray(Field &);
void prntAry(Field &,int);
void prntAry(int [],int ,int);
void mrkSort(Field &);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    const int SIZE=100;
    int array[SIZE];
    int index[SIZE];
    
    //Fill the structure with the size and the array
    Field field;     //Declare the structure
    field.size=SIZE; //Initialize the structure Size
    field.a=array;   //Initialize the structure Data
    field.indx=index;//Initialize the structure Index
    
    //Initialize Variables
    filAray(field);
    
    //Print the Array
    cout<<"Original Data Array"<<endl;
    prntAry(field.a,SIZE,10);
    cout<<"Indexed Array before sorting"<<endl;
    prntAry(field.indx,SIZE,10);
    
    //Process or map the inputs to the outputs
    mrkSort(field);
    
    //Display/Output all pertinent variables
    cout<<"The Original Array after Sorting"<<endl;
    prntAry(field.a,SIZE,10);
    cout<<"Indexed Array after sorting"<<endl;
    prntAry(field.indx,SIZE,10);
    cout<<"The Original Array printed with the sorted Index"<<endl;
    prntAry(field,10);
    
    //Exit the program
    return 0;
}

void mrkSort(Field &field){
    for(int pos=0;pos<field.size-1;pos++){
        for(int i=pos+1;i<field.size;i++){
            if(field.a[field.indx[pos]]>field.a[field.indx[i]]){
                int temp=field.indx[pos];
                field.indx[pos]=field.indx[i];
                field.indx[i]=temp;
            }
        }
    }
}

void prntAry(Field &field,int perLine){
    cout<<endl;
    for(int i=0;i<field.size;i++){
        cout<<field.a[field.indx[i]]<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
}

void prntAry(int a[],int n,int perLine){
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
}

void filAray(Field &field){
    for(int i=0;i<field.size;i++){
        field.a[i]=rand()%90+10;
        field.indx[i]=i;
    }
}