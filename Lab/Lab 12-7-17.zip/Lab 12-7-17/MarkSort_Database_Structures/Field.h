/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on December 7th, 2017, 11:30 AM
 * Purpose:  Our first structure used in sorting 
 */



#ifndef FIELD_H
#define FIELD_H

struct Field{
    int size;  //Size of the array
    int *a;    //The array containing our data
    int *indx;//index to the array data
};

#endif /* FIELD_H */

