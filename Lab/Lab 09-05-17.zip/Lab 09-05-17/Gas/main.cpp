/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 5, 20167, 11:37 AM
 * Purpose:  Hello World Template
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float fedGs; // Federal's Gas 
    float stGs; // State Gas
    float pctST; // Percentage of State Tax
    float gsp; // Gas Price
    float OCP;//Oil Company Profit
    
    //Input or initialize values Here
    fedGs=18.4;//18.4 cents
    stGs=36;//36 cents
    pctST=8;
    OCP=7;//7 cents
    
    //Process/Calculations Here
    
    
            
    //Output Located Here
    cout<<"NASA's 2017 budget = $"<<nasaBudg<<endl;
    cout<<"DOD's 2017 budget = $"<<dodBudg<<endl;
    cout<<"Fed's 2017 budget = $"<<fedBudg<<endl;
    cout<<"NASA's percentage of total "<<pctNASA<<"%"<<endl;
    cout<<"DOD's percentage of Total "<<pctDOD<<"%"<<endl;

    //Exit
    return 0;
}

