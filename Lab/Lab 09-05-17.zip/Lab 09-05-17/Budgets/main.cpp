/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on September 5, 20167, 11:37 AM
 * Purpose:  Hello World Template
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float fedBudg; // US federal Budget
    float dodBudg; //DOD Budget
    float nasaBudg; // NASA Budget
    float pctDOD;//Percentage of DOD Budget as a function of Federal
    float pctNASA;//Percentage of NASA Budget as a function of Federal
    
    //Input or initialize values Here
    fedBudg=3.8e12f;//3.8 trillion
    dodBudg=609e9f;//609 Billion
    nasaBudg=18.4e9f;//18.4 billion
            
    //Process/Calculations Here
    pctDOD=dodBudg/fedBudg*100;
    pctNASA=nasaBudg/fedBudg*100;
    
            
    //Output Located Here
    cout<<"NASA's 2017 budget = $"<<nasaBudg<<endl;
    cout<<"DOD's 2017 budget = $"<<dodBudg<<endl;
    cout<<"Fed's 2017 budget = $"<<fedBudg<<endl;
    cout<<"NASA's percentage of total "<<pctNASA<<"%"<<endl;
    cout<<"DOD's percentage of Total "<<pctDOD<<"%"<<endl;

    //Exit
    return 0;
}

