/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on December 5th, 2017, 12:19 PM
 * Purpose:  Testing to number of exchanges made
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
#include <ctime>        //Time Library
#include <cstdlib>      //Srand and rand Library
using namespace std;    //Standard Name-space under which System Libraries reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes
void filAray(int [],int);
int bubSort(int [],int);
int selSort(int [],int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
     srand(static_cast<unsigned int>(time(0)));
     
    //Declare Variables
    const int SIZE=20;//The size of the array
    int test[SIZE]={};//The array used to test the sorts
    
    //Initialize Variables
    filAray(test,SIZE);
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    bubSort(test,SIZE);
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}

int bubSort(int test[],int SIZE){
    bool swap=false;
    int temp;
    do{
    for (int cnt;cnt<SIZE;cnt++){
        if(test[cnt]>test[cnt+1])
        temp=test[cnt];
        test[cnt]=test[cnt+1];
        test[cnt+1]=temp;
    }
    }while(swap)
}

void filAray(int test[],int SIZE){
    for (int i;i<SIZE;i++){
        test[i]=rand()%20+1;
    }
}