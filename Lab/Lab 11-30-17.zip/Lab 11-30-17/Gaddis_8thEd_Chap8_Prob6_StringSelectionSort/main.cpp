/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on November 30th, 2017 12:07 PM
 * Purpose:  Sorting a String using Selection Sort
 */

//System Libraries Here
#include <iostream> //Input/Output Library
#include <string>   //String Library
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here
void selSort(string [],int);//Used for Selection Sort
//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int SIZE=20;   //The size of the array 
    string name[SIZE]={"Collins,Bill","Smith,Bart","Allen,Jim","Griffin,Jim",
            "Stamey,Marty","Rose,Geri","Taylor, Terri","Johnson,Jill",
            "Allison,Jeff","Looney,Joe","Wolfe,Bill","James,Jean","Weaver,Jim",
            "Pore,Bob","Rutherford,Greg","Javens,Renee","Harrison,Rose","Setzer,Cathy",
            "Pike,Gordon","Holland Beth"};
    
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    for(int i;i<SIZE;i++){
        cout<<name[i]<<endl;
    }
        
    //Output Located Here
    

    //Exit
    return 0;
}

