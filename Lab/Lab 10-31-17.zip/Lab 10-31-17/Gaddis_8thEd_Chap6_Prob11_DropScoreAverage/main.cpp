/* 
 * File:   main.cpp
 * Author: Ivan Burgos
 * Created on October 31, 2017, 12:17 PM
 * Purpose:  Hello World Template
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
float getScore();
float fndLowst(float &);
float average();

//Program Execution Begins Here
int main(int argc, char** argv) {
   //Display/Output all pertinent variables
    cout<<"The Average 4 Highest Scores = "<<average()<<endl;
    
    //Exit
    return 0;
}

float average(){
    float sum;
    float lowest=fndLowst(sum);
    return (sum-lowest)/4;
}

float fndLowst(float &sum){
    sum=0;
    float lowest=getScore();
    sum+=lowest;
    for (int i=1;i<=4;i++){
        float add=getScore();
        if (add<lowest)lowest=add;
        sum+=add;
    }
    return lowest;
}

float getScore(){
    static int cnt=1;
    float score;
    cout<<"Type in Test score "<<cnt++<<endl;
    cin>>score;
    return score;
}

